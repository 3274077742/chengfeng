<?php
$jhwjm = '../regdata.php';
$jhgqsj = time() + 365 * 24 * 60 * 60; //一年后

$gdz1 = '4LbFnUKUsDxyuXXkN7fRK4';
$gdz2 = 'TDBk4szBg7Hcn3svKEdAqw';

$jhjym = sha1($jhgqsj . $gdz1 . $dename . $gdz2);

$jhwjnr = <<<EOF
<?php
\$jhgqsj = $jhgqsj;
\$jhjym = '$jhjym';
EOF;


file_put_contents($jhwjm, $jhwjnr);


$dq = file_get_contents($jhwjm);

if ($dq != $jhwjnr) {

    exit("安装失败3，请检查目录是否有写入权限。");
}
?>