<?php
session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<?php
    $uid = $_GET['uid'];
    require "../../config.php";
    $sql = "DELETE FROM `admininfo` WHERE `admininfo`.`Uid` = $uid";
    if(mysqli_query($mysql_link,$sql)){
        echo "<script language=\"javascript\">
  alert(\"删除成功，返回浏览页\");
  document.location.href=\"../user.php\";
</script>";
    }else{
        echo "<script language=\"javascript\">
  alert(\"删除失败，返回浏览页\");
  document.location.href=\"../user.php\";
</script>";
    }
mysqli_close($mysql_link);
?>