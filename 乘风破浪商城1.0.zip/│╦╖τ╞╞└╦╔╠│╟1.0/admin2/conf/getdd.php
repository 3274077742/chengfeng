<?php
    $ip=$_POST['ip'];
    $d_name = $_POST['d_name'];
$d_phone = $_POST['d_phone'];
$d_youbian = $_POST['d_youbian'];
$d_city = $_POST['d_city'];
$d_tle = $_POST['d_tle'];
$uid = $_POST['uid'];
$ddh=time() . rand(100000,9999999) . rand(100000,9999999);
require "../../config.php";
    $csp = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `shop` WHERE `s_uid` = $uid"));
    $nid= $csp['s_pid'];
    $pid = $csp['s_uid'];
    mysqli_query($mysql_link,"INSERT INTO `dingdan` (`d_uid`, `d_pid`, `d_nid`, `d_sid`, `d_leibie`, `d_ip`, `d_name`, `d_phone`, `d_youbian`, `d_city`, `d_tle`) VALUES (NULL, '$uid', '$nid', '$ddh', '转转', '$ip', '$d_name', '$d_phone', '$d_youbian', '$d_city', '$d_tle')");
echo "<script language=\"javascript\">
  document.location.href=\"../../zz/order2.php?uid=$uid\";
</script>";
?>