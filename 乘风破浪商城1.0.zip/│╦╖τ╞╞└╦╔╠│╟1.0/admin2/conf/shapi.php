<?php
session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}

?>
<?php
    $sh_key=$_POST['sh_key'];
$sh_id=$_POST['sh_id'];
$sh_tbdz=$_POST['sh_tbdz'];
$sh_ybdz=$_POST['sh_ybdz'];
    require "../../config.php";
    $xiugai=mysqli_query($mysql_link,"UPDATE `shapi` SET `sh_key` = '$sh_key', `sh_id` = '$sh_id', `sh_tbdz` = '$sh_tbdz', `sh_ybdz` = '$sh_ybdz' WHERE `shapi`.`uid` = 1");
    if($xiugai){
        echo "<script language=\"javascript\">
  alert(\"修改成功\");
  document.location.href=\"../shapi.php\";
</script>";
    }else{
        echo "<script language=\"javascript\">
  alert(\"修改失败\");
  document.location.href=\"../shapi.php\";
</script>";
    }
?>