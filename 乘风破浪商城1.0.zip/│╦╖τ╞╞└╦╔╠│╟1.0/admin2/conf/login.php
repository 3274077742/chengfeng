<?php
session_start();
require "../../config.php";
$name = $_POST['adname'];
$pawd = $_POST['adpasswd'];
if($name=='' or $pawd==''){
    echo "<script language=\"javascript\">
  alert(\"账号或密码不能为空，请重新登录\");
  document.location.href=\"../login.php\";
</script>";
}
$cx = mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$name' AND `adminPwd` = '$pawd'");
$row = mysqli_fetch_array($cx);
if($row==null){
    echo "<script language=\"javascript\">
  alert(\"账号或密码错误，请重新登录\");
  document.location.href=\"../login.php\";
</script>";
}else{
    $_SESSION['UserName']=$name;
    echo "<script language=\"javascript\">
  alert(\"登陆成功\");
  document.location.href=\"../index.php\";
</script>";

}
mysqli_close($mysqllink);



?>