﻿<? header("content-Type: text/html; charset=UTF-8");?>
<?php

	include_once("./config.php");
	$user_no 	   = $apiName;	// 接入终端号
	$banktype  = "bank";					//提现方式：网银：bank 微信：weixin_scan 支付宝：alipay_scan  QQ：qq_scan
	$money         = "100";						//提现金额
	$money_date	   = time();		//订单时间
	$bank_code    = '123456464555654654554';		//提现账号
	$client_ip     = $_SERVER["REMOTE_ADDR"];		//客户端IP
	$user_key 	   =  $apikey;			//商户密钥
	$user_name  = "sss";	// 提现账号用户名
	/****************************************************/
	$signStr= "";
	if($bank_code != ""){
		$signStr = $signStr."bank_code=".$bank_code."&";
	}
	$signStr = $signStr."banktype=".$banktype."&";
	if($client_ip != ""){
		$signStr = $signStr."client_ip=".$client_ip."&";
	}
	$signStr = $signStr."money=".$money."&";
	$signStr = $signStr."money_date=".$money_date."&";
	$signStr = $signStr."user_name=".$user_name."&";
	$signStr = $signStr."user_no=".$user_no."&";
	/*******************************************************/
	$signMsg = MD5($signStr.$user_key);
	
	$postdata= array(
		'user_no'    => $user_no,
		'banktype'   => $banktype,
		'money'      => $money,
		'money_date' => $money_date,
		'bank_code'  => $bank_code,
		'client_ip'  => $client_ip,
		'user_name'  => $user_name,
		'signMsg'    => $signMsg,
	);
	
	$postdata = http_build_query($data);
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "http://pay.pay592.com/payapi/cash?input_charset=UTF-8");
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
	$result = curl_exec($ch);
	curl_close($ch);
	echo $result;
	

