<?php
session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}

?>
<?php
    require "../config.php";
    $pageSize = 5;
    $cxadmin = mysqli_query($mysql_link,"SELECT COUNT(*) From admininfo");
    $rest = mysqli_fetch_row($cxadmin);
    $pageCount = ceil($rest[0]/$pageSize);
    $currpage = empty($_GET['page'])?1:$_GET['page'];
    if($currpage>$pageSize){
        $currpage=1;
    }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>乘风破浪1.0后台-用户管理</title>
    <link href="./bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="row">
    <div class="col-md-12">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="#">
                                <img alt="Brand" src="./logo.png" width="35px" height="30px">
                            </a>
                        </div>
                    </div>
                </div>


                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li ><a href="index.php">后台首页 </a></li>
                        <li class="active"><a href="#">用户管理<span class="sr-only">(current)</span></a></li>
                        <li><a href="./shapi.php">商户信息</a></li>
                        <li><a href="./rmuser.php">修改密码</a></li>
                        <li><a href="./shoplist.php#">查看商品</a></li>
                        <li><a href="./showdd.php">订单查看</a></li>
                        <li><a href="./ad.php">发布商品</a></li>

                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">管理员：<?php echo $_SESSION["UserName"]; ?></a></li>
                        <li><a href="./conf/zhuxiaologin.php">注销登录</a></li>

                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="list-group" style="text-align: center">
                <a href="#" class="list-group-item active" style="font-size: 20px">
                   注册用户：<?php echo $rest[0]; ?>人
                </a>
                <ul class="list-group">
  <li class="list-group-item">
      <div class="table-responsive">
          <table class="table">
      <tr>
      <td class="active" style="text-align: center">ID</td>
          <td class="info" style="text-align: center"></td>
      <td class="success" style="text-align: center">用户名</td>
      <td class="warning" style="text-align: center">密码</td>
      <td class="info" style="text-align: center">QQ</td>
      <td class="info" style="text-align: center">操作</td>
  </tr>
              <?php
              $adminsql = "SELECT * FROM admininfo limit ".($currpage-1)*$pageSize.",".$pageSize;
              $adcx = mysqli_query($mysql_link,$adminsql);
              while($row23 = mysqli_fetch_array($adcx)){
                  $rest1[] = $row23;
              }
              if(@$rest1!=null){
              foreach ($rest1 as $key=>$rowadmin) {
                  $rowadmin_id = $rowadmin['Uid'];
                  $rowadmin_pid = $rowadmin['Pid'];
                  $rowadmin_name = $rowadmin['adminName'];
                  $rowadmin_pwd = $rowadmin['adminPwd'];
                  $rowadmin_qq = $rowadmin['adminQq'];


              if($rowadmin_pid==1){
                  echo "<tr>
                  <td class='' style='text-align: center'>$rowadmin_id</td>
                  <td class='' style='text-align: center'>管理员</td>
                  <td class='' style='text-align: center'>$rowadmin_name</td>
                  <td class='' style='text-align: center'>$rowadmin_pwd</td>
                  <td class='' style='text-align: center'>$rowadmin_qq</td>
                  <td class='' style='text-align: center'><a href='./rmuser2.php?uid=$rowadmin_id'>改</a>|<a href='./conf/scad.php?uid=$rowadmin_id'>删</a></td>
              </tr>";
              }else{
                  echo "<tr>
                  <td class='' style='text-align: center'>$rowadmin_id</td>
                  <td class='' style='text-align: center'>会员</td>
                  <td class='' style='text-align: center'>$rowadmin_name</td>
                  <td class='' style='text-align: center'>$rowadmin_pwd</td>
                  <td class='' style='text-align: center'>$rowadmin_qq</td>
                  <td class='' style='text-align: center'><a href='./rmuser2.php?uid=$rowadmin_id'>改</a>|<a href='./conf/scad.php?uid=$rowadmin_id'>删</a></td>
              </tr>";
              } }
              }
              ?>

          </table>
      </div>
      <ul class="pagination">
          <?php
          @$page=$_GET['page'];
          if($page==0){
            echo "<li>
              <a href=\"\" aria-label=\"Previous\">
                  <span aria-hidden=\"true\">&laquo;</span>
              </a>
          </li>";
          }else{
                $page1=$page-1;
              echo "<li>
              <a href=\"./user.php?page=$page1\" aria-label=\"Previous\">
                  <span aria-hidden=\"true\">&laquo;</span>
              </a>
          </li>";
          }
          for($i=1;$i<=$pageCount;$i++){
              if($i==$page){

                  echo "<li class=\"active\"><span>$i <span class=\"sr-only\">(current)</span></span></li>";
              }else{
                  echo "<li><a href=\"./user.php?page=$i\">$i</a></li>";
              }
          }

            if($page>=$pageCount){
              echo "         <li>
              <a href=\"./user.php?page=$page\" aria-label=\"Next\">
                  <span aria-hidden=\"true\">&raquo;</span>
              </a>
          </li>";
            }else{
                $page2=$page+1;
              echo "         <li>
              <a href=\"./user.php?page=$page2\" aria-label=\"Next\">
                  <span aria-hidden=\"true\">&raquo;</span>
              </a>
          </li>";
            }
          ?>



      </ul>

  </li>

</ul>
            </div>
        </div>

    </div>
</div>


<div class="container">
    <div class="row">
        <div class="col-md-12">

            <div class="list-group" style="text-align: center">
                <a href="#" class="list-group-item active">
                   新增用户
                </a>
                <form action="./conf/addad.php" method="post">
                <ul class="list-group">
                    <li class="list-group-item"><div class="input-group">
                        <span class="input-group-addon" id="sizing-addon2">用户名</span>
                        <input type="text" name="adname" class="form-control" placeholder="用户名" aria-describedby="sizing-addon2">
                    </div></li>
                    <li class="list-group-item"><div class="input-group">
                        <span class="input-group-addon" id="sizing-addon2">密&nbsp;&nbsp;&nbsp;码</span>
                        <input type="password" name="adpwd" class="form-control" placeholder="密码" aria-describedby="sizing-addon2">
                    </div></li>
                    <li class="list-group-item"><div class="input-group">
                        <span class="input-group-addon" id="sizing-addon2">Q&nbsp;&nbsp;&nbsp;&nbsp;Q</span>
                        <input type="text" name="adqq" class="form-control" placeholder="QQ号码" aria-describedby="sizing-addon2">
                    </div></li>
                    <li class="list-group-item"><div class="input-group">
                        <span class="input-group-addon" id="sizing-addon2">用户组</span>
                        <input type="text" name="adpid" class="form-control" placeholder="管理员1，会员2" aria-describedby="sizing-addon2">
                    </div></li>
                    <li class="list-group-item"><button type="submit" class="btn btn-info">确认增加</button></li>
                </ul>
                </form>
            </div>




        </div>
    </div>

</div>
<?php
require "./dibu..inc.php";

?>
<script src="./jquery-3.2.1/jquery-3.2.1.js"></script>
<script src="./bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>