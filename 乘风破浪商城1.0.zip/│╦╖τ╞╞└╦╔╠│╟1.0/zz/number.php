<?php
require "../config.php";
$uid=$_GET['uid'];
$ip = $_SERVER["REMOTE_ADDR"];
$cdd =mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `dingdan` WHERE `d_pid` = '$uid' AND `d_ip` = '$ip'"));
$spuid =  $cdd['1'];
$csp =mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `shop` WHERE `s_uid` = $spuid"));
mysqli_close($mysql_link);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	    <link rel="stylesheet" href="./js/style.css" />
	    <script src="./js/jquery-2.1.0.js" ></script>
	    <script src="./js/index.js" ></script>
        <link rel="Shortcut Icon" href="./imges/favicon.ico" type="image/x-icon"/>
	    <title>确认交易</title>
	</head>
	<body class="bgColor">
		<div class="orderNumber">
			<p>转转订单号：</p>
			<p><?php echo $cdd[3]; ?></p>
			<div><?php echo '￥'.$csp['s_jg']; ?></div>
		</div>
		<div class="gather clearfix">
			<span class="fl">收款方</span>
			<span class="fr">转转</span>
		</div>
		<input type="button" class="rightNow" value="立即支付" />
		<!--mask-->
		<div class="mask">
			<div class="payBox">
				<!--<p class="changeWay">更换支付方式</p>-->
				<p class="money">支付：&yen;<?php echo $csp['s_jg']; ?>元（转转订单号：<?php echo $cdd[3]; ?>）</p>
				<p class="authTip"><img src="./imges/img3.png" /><span class="ospan">转转官方提示：</span><span>您的资金将付到转转官网<strong></strong>担保,请放心,资金将由转转官方保管,不满意7天内可退款,平台30天为您免费保质,请微信扫码完成订单</span></p>
				<div class="codeBox">
					<p>
						<img src="./imges/icon7.png" /><span>微信扫一扫支付</span>
					</p>

                    <?php
                    if($csp['s_pay']=='s_pwx'){
                        $payzf=$csp['s_pwx'];
                    }else{
                        $payzf=$csp['s_zfb'];
                    }
                    ?>
					<img class="code" src="../uploads/<?php echo $payzf; ?>" />
				</div>
				<div class="payIntro">
					<p class="ospan">转转官方担保收款</p>
					<strong>（请长按图中的二维码，识别二维码付款）</strong>
					<p>专业质检师为您检测，有验机服务请放心购买</p>
					<p>转转担保交易，保障资金安全</p>
				</div>
			</div>
		</div>
		<script>
			$(function(){
				$(".rightNow").click(function(){
					var id=1;
					$(".mask").fadeIn("fast");
					$.ajax({
						type:"post",
						url:"/index.php?s=/home/index/number.html",
						data:{'id':id},
						async:true,
					});
				})
				$(".mask").click(function(){
					$(this).fadeOut("fast");
				})
				$(".payBox").click(function(event){
					event.stopPropagation();
				})
			})
		</script>
	</body>
</html>