<?php
session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<?php
    require "../../config.php";
    $uid = $_GET['uid'];
$s_mz=$_POST['s_mz'];
$s_jg=$_POST['s_jg'];
$s_mjmz=$_POST['s_mjmz'];
$s_zt=$_POST['s_zt'];
$s_pay=$_POST['s_pay'];
$s_djl=$_POST['s_djl'];
$s_ys=$_POST['s_ys'];
$s_nc=$_POST['s_nc'];
$s_qd=$_POST['s_qd'];
$s_dq=$_POST['s_dq'];
$s_js=$_POST['s_js'];
$s_zssl=$_POST['s_zssl'];
$s_jysl=$_POST['s_jysl'];
$s_hfl=$_POST['s_hfl'];
require_once "./common.func.php";
require_once "./upload.function1.php";
$files = getFiles();
foreach ($files as $fileInfo){
    $res =uploadFile($fileInfo);

    @$uploadFiles[]=$res['dest'];
}
$img1=basename(@$uploadFiles[0]);
$img2=basename(@$uploadFiles[1]);
$img3=basename(@$uploadFiles[2]);
$img4=basename(@$uploadFiles[3]);
$img5=basename(@$uploadFiles[4]);
$s_mjtx=basename(@$uploadFiles[5]);
$s_paytp=basename(@$uploadFiles[6]);

if($s_pay==1){
    $s_pay='s_pwx';
}else{
    $s_pay='s_pzfb';
}
if($img2 !=NULL){
    $img21 = mysqli_query($mysql_link,"UPDATE `shop` SET `s_tp2` = '$img2' WHERE `shop`.`s_uid` = $uid;");
    if(!$img21){
        exit("图片2上传失败");
    }
}
if($img3 !=NULL){
    $img31 = mysqli_query($mysql_link,"UPDATE `shop` SET `s_tp3` = '$img3' WHERE `shop`.`s_uid` = $uid;");
    if(!$img31){
        exit("图片3上传失败");
    }
}
if($img4 !=NULL){
    $img41 = mysqli_query($mysql_link,"UPDATE `shop` SET `s_tp4` = '$img4' WHERE `shop`.`s_uid` = $uid;");
    if(!$img41){
        exit("图片4上传失败");
    }
}
if($img5 !=NULL){
    $img51 = mysqli_query($mysql_link,"UPDATE `shop` SET `s_tp5` = '$img5' WHERE `shop`.`s_uid` = $uid;");
    if(!$img51){
        exit("图片5上传失败");
    }
}
if($img1 !=NULL){
    $img11 = mysqli_query($mysql_link,"UPDATE `shop` SET `s_tp1` = '$img1' WHERE `shop`.`s_uid` = $uid;");
    if(!$img11){
        exit("图片1上传失败");
    }
}
if($s_mjtx !=NULL){
    $s_mjtx1 = mysqli_query($mysql_link,"UPDATE `shop` SET `s_mjtx` = '$s_mjtx' WHERE `shop`.`s_uid` = $uid;");
    if(!$s_mjtx1){

    }
}
if($s_paytp !=NULL){
    $s_paytp1 = mysqli_query($mysql_link,"UPDATE `shop` SET `$s_pay` = '$s_paytp' WHERE `shop`.`s_uid` = $uid;");
    if(!$s_paytp1){

    }
}

$adzzshop="UPDATE `shop` SET `s_mjmz` = '$s_mjmz', `s_mz` = '$s_mz', `s_jg` = '$s_jg', `s_zt` = '$s_zt', `s_pay` = '$s_pay', `s_djl` = '$s_djl', `s_ys` = '$s_ys', `s_nc` = '$s_nc', `s_qd` = '$s_qd', `s_dq` = '$s_dq', `s_js` = '$s_js', `s_zssl` = '$s_zssl', `s_jysl` = '$s_jysl', `s_hfl` = '$s_hfl' WHERE `shop`.`s_uid` = $uid";
if(mysqli_query($mysql_link,$adzzshop)){
    if($s_pay=='s_pzfb' and $s_paytp!=''){
        $ym=$_SERVER['SERVER_NAME'];
        echo "<a href='http://$ym/imgapi/tp2.php?tpm=$s_paytp'>点击生成支付宝链接</a>";
        mysqli_close($mysql_link);
    }else{echo "<script language=\"javascript\">
  alert(\"修改商品成功，返回继续浏览\");
  document.location.href=\"../shoplist.php\";
</script>";
        exit;}

}else{
    echo "<script language=\"javascript\">
  alert(\"修改商品失败'</br>'\");
  document.location.href=\"../shoplist.php\";
</script>";
    exit;
}

?>
