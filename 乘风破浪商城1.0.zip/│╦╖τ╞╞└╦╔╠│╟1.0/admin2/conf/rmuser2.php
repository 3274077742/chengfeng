<?php
session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<?php

require "../../config.php";
$uid=$_GET['uid'];
$adminName=$_POST['adminName'];
$adminQq = $_POST['adminQq'];
$adminNpwd = $_POST['adminNpwd'];
$adminPid = $_POST['adminPid'];
$row1 = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE Uid = '$uid'"));


    if(mysqli_query($mysql_link,"UPDATE `admininfo` SET `Pid` = '$adminPid', `adminName` = '$adminName', `adminPwd` = '$adminNpwd', `adminQq` = '$adminQq' WHERE `admininfo`.`Uid` = $uid"))
    {
        echo "<script language=\"javascript\">
  alert(\"用户资料更新成功！返回继续浏览\");
  document.location.href=\"../user.php\"; 
</script>";
        mysqli_close($mysql_link);
        exit;
    }else{
        echo "<script language=\"javascript\">
  alert(\"修改失败，重新修改！\");
  document.location.href=\"../rmuser2.php\"; 
</script>";
        mysqli_close($mysql_link);
        exit;
    }


?>