-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2018-02-23 18:44:42
-- 服务器版本： 5.6.39-log
-- PHP Version: 7.0.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `www_zhuanzhuan5`
--

-- --------------------------------------------------------

--
-- 表的结构 `admininfo`
--

CREATE TABLE IF NOT EXISTS `admininfo` (
  `Uid` int(11) NOT NULL COMMENT 'uid',
  `Pid` int(11) NOT NULL COMMENT '用户组',
  `adminName` varchar(32) NOT NULL COMMENT '用户名',
  `adminPwd` text NOT NULL COMMENT '密码',
  `adminQq` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='管理员表';

--
-- 转存表中的数据 `admininfo`
--

INSERT INTO `admininfo` (`Uid`, `Pid`, `adminName`, `adminPwd`, `adminQq`) VALUES
(1, 1, 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- 表的结构 `dingdan`
--

CREATE TABLE IF NOT EXISTS `dingdan` (
  `d_uid` int(11) NOT NULL,
  `d_pid` int(11) NOT NULL,
  `d_nid` int(11) NOT NULL,
  `d_sid` varchar(32) NOT NULL,
  `d_leibie` text NOT NULL,
  `d_ip` text NOT NULL,
  `d_name` text NOT NULL,
  `d_phone` text NOT NULL,
  `d_youbian` text NOT NULL,
  `d_city` text NOT NULL,
  `d_tle` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8 COMMENT='订单';

-- --------------------------------------------------------

--
-- 表的结构 `shapi`
--

CREATE TABLE IF NOT EXISTS `shapi` (
  `uid` int(11) NOT NULL,
  `sh_key` text NOT NULL,
  `sh_id` text NOT NULL,
  `sh_tbdz` text NOT NULL,
  `sh_ybdz` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `shapi`
--

INSERT INTO `shapi` (`uid`, `sh_key`, `sh_id`, `sh_tbdz`, `sh_ybdz`) VALUES
(1, '6464ff00b3aa3a0bec9c860919886535', '1802227021', 'http://www.zhaunzhaun.com/pay/returnback.php', 'http://www.zhaunzhaun.com/pay/notifyback.php');

-- --------------------------------------------------------

--
-- 表的结构 `shop`
--

CREATE TABLE IF NOT EXISTS `shop` (
  `s_uid` int(11) NOT NULL,
  `s_pid` int(11) NOT NULL,
  `s_leibie` int(11) NOT NULL,
  `s_mjmz` text NOT NULL,
  `s_mz` text NOT NULL,
  `s_jg` text NOT NULL,
  `s_zt` text NOT NULL,
  `s_pay` text NOT NULL,
  `s_djl` text NOT NULL,
  `s_ys` text NOT NULL,
  `s_nc` text NOT NULL,
  `s_qd` text NOT NULL,
  `s_dq` text NOT NULL,
  `s_js` text NOT NULL,
  `s_zssl` text NOT NULL,
  `s_jysl` text NOT NULL,
  `s_hfl` text NOT NULL,
  `s_tp1` text NOT NULL,
  `s_tp2` text NOT NULL,
  `s_tp3` text NOT NULL,
  `s_tp4` text NOT NULL,
  `s_tp5` text NOT NULL,
  `s_mjtx` text NOT NULL,
  `s_pzfb` text NOT NULL,
  `s_pwx` text NOT NULL,
  `s_zfblink` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admininfo`
--
ALTER TABLE `admininfo`
  ADD UNIQUE KEY `Uid` (`Uid`),
  ADD UNIQUE KEY `adminName` (`adminName`);

--
-- Indexes for table `dingdan`
--
ALTER TABLE `dingdan`
  ADD UNIQUE KEY `d_uid` (`d_uid`);

--
-- Indexes for table `shapi`
--
ALTER TABLE `shapi`
  ADD UNIQUE KEY `uid` (`uid`);

--
-- Indexes for table `shop`
--
ALTER TABLE `shop`
  ADD UNIQUE KEY `z_uid` (`s_uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admininfo`
--
ALTER TABLE `admininfo`
  MODIFY `Uid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'uid',AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `dingdan`
--
ALTER TABLE `dingdan`
  MODIFY `d_uid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT for table `shapi`
--
ALTER TABLE `shapi`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `shop`
--
ALTER TABLE `shop`
  MODIFY `s_uid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=79;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
