<?php
require "../config.php";
$uid= $_GET['uid'];
$pay=$_GET['zfid'];
$ip = $_SERVER["REMOTE_ADDR"];
$cdd =mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `dingdan` WHERE `d_pid` = '$uid' AND `d_ip` = '$ip'"));
$spuid =  $cdd['1'];
$csp =mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `shop` WHERE `s_uid` = $spuid"));

mysqli_close($mysql_link);

function is_weixin(){

    if ( strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false ) {
        return true;
    }
    return false;
}
if($pay!='alipay'){
    if(is_weixin()){

        echo "<html>
    <head>
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0\">
        <meta name=\"format-detection\" content=\"telephone = no\" />
        <title>微信支付</title>
        <base href=\"/statics/templates/mobile/\"/>
		<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">
    <style type=\"text/css\">
    body,td,th {
	color: #FFF;
}
body {
	background-color: #999;
}
    .img {
	text-align: center;
}
    </style>
    </head>
    <body >
    <div class=\"img\" id=\"5\"><img src=\"./img/tiao.png\" width=\"320\" height=\"500\"><br/> <h2><font color=\"#FF6633\">请按照提示操作完成支付！！！</font></h2>
    </div>
</body>
</html>";
        exit;
    }else {
        echo "<script language=\"javascript\">
  document.location.href=\"./order2.php?uid=$uid\";
</script>";
    }
}else{
    /**
     * 检测是否在QQ微信
     */
    $conf['qqjump'] = 1;
    if (strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false && $conf['qqjump'] == 1) {
        $a = 'http://' . $_SERVER['SERVER_NAME'] . ':' . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
        echo '<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<script src="https://open.mobile.qq.com/sdk/qqapi.js?_bid=152"></script>;
<script type="text/javascript"> mqq.ui.openUrl({ target: 2,url: "' . $a . '"}); </script>
</head>
<body>
</body>
</html>';
        exit;
    }


    if(is_weixin()){
        echo "<html>
    <head>
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0\">
        <meta name=\"format-detection\" content=\"telephone = no\" />
        <title>微信支付</title>
        <base href=\"/statics/templates/mobile/\"/>
		<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">
    <style type=\"text/css\">
    body,td,th {
	color: #FFF;
}
body {
	background-color: #999;
}
    .img {
	text-align: center;
}
    </style>
    </head>
    <body >
    <div class=\"img\" id=\"5\"><img src=\"./img/tiao.png\" width=\"320\" height=\"500\"><br/> <h2><font color=\"#FF6633\">请按照提示操作完成支付！！！</font></h2>
    </div>
</body>
</html>";
        exit;
    }

    $link = $csp['s_zfblink'];
    echo "<script language=\"javascript\">
  document.location.href=\"$link\";
</script>";


}
?>