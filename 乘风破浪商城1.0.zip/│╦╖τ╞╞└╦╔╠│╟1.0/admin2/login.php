<?php

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>乘风破浪1.0后台-修改密码</title>
    <link href="./bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="row">
    <div class="col-md-12">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="#">
                                <img alt="Brand" src="./logo.png" width="35px" height="30px">
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->

            </div><!-- /.container-fluid -->
        </nav>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">

            <div class="list-group" style="text-align: center">
                <a href="#" class="list-group-item active">
                    登录后台
                </a>
                <form action="./conf/login.php" method="post">
                    <ul class="list-group">
                        <li class="list-group-item"><div class="input-group">
                                <span class="input-group-addon" id="sizing-addon2">用户名</span>
                                <input type="text" name="adname" class="form-control" placeholder="请输入用户名" aria-describedby="sizing-addon2">
                            </div></li>
                        <li class="list-group-item"><div class="input-group">
                                <span class="input-group-addon" id="sizing-addon2">密    码</span>
                                <input type="password" name="adpasswd" class="form-control" placeholder="请输入密码" aria-describedby="sizing-addon2">
                            </div></li>

                        <li class="list-group-item"><button type="submit" class="btn btn-info">点击登录</button></li>
                    </ul>
                </form>
            </div>




        </div>
    </div>

</div>
<?php
    require_once "./dibu..inc.php";
?>
<script src="./jquery-3.2.1/jquery-3.2.1.js"></script>
<script src="./bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>