<?php
    require "../config.php";
$uid=$_GET['uid'];
    $cxsql= mysqli_query($mysql_link,"SELECT * FROM shop WHERE s_uid = $uid");
    $row = mysqli_fetch_array($cxsql);
    mysqli_close($mysql_link);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./js/style.css" />
    <script src="./js/jquery-2.1.0.js" ></script>
    <script src="./js/index.js" ></script>
    <link rel="Shortcut Icon" href="./imges/favicon.ico" type="image/x-icon"/>
    <title>订单确认</title>
</head>
<body class="bgColor" style="padding-bottom: 4rem;">
<!--2017-7-11-->
<div class="blackBox">
    <img src="./imges/icon24.png" />
    <p>请填写收货地址</p>
</div>
<!--2017-7-11-->

<div>
    <p class="tip">验机服务须知：验机商品将由卖家先寄往平台进行质检，请拒绝卖家私下为您发货；您确认购买手机后，钱款将立刻打给卖家。</p>
    <div class="addSite">
        <a href="<?php echo "./addres.php?uid=$uid"?>" class="clearfix">
            <span class="local fl"></span>
            <span class="word fl">新增地址</span>
            <span class="gt fr"></span>
        </a>
    </div>
    <div class="goodBox">
        <div class="storeLogo clearfix">
            <div class="storeBox fl">
                <img class="head" src="../uploads/<?php echo $row['s_mjtx']; ?>" alt="店铺头像" />
                <img class="icon" src="./imges/icon3.png" />
            </div>
            <span class="fl"><?php echo $row['s_mjmz']; ?></span>
        </div>
        <div class="goodInfo">
            <img class="fl" src="../uploads/<?php echo $row['s_tp1']; ?>" alt="商品图片" />
            <div class="goodDetail fl">
                <p><?php echo $row['s_js']; ?></p>
                <span><em>&yen;</em><?php echo $row['s_jg']; ?></span>
            </div>
        </div>
        <div class="delivery clearfix">
            <span class="fl">配送方式</span>
            <p class="fr"><span>快递</span><em>&yen;&nbsp;</em>0</p>
        </div>
    </div>
    <p class="payWay">特色服务</p>
    <div class="service clearfix">
        <span class="check active fl"></span>
        <div class="feature fl">
            <div class="zhuanBox clearfix">
                <div class="zhuan fl">
                    <img src="./imges/icon9.png" /><span>优品验机服务+30天质保</span><img src="./imges/icon4.png" />
                    <p>赠送20元保价顺丰包邮</p>
                </div>
                <div class="experience fr">
                    <span>原价78</span>&yen;&nbsp;9<br />
                    <em>体验价</em>
                </div>
            </div>
            <ul class="primeCost">
                <li><span>专业验机</span><span>原价&nbsp;&yen;&nbsp;29</span></li>
                <li><span>30天质保</span><span>原价&nbsp;&yen;&nbsp;29</span></li>
                <li><span>顺丰保价包邮</span><span>原价&nbsp;&yen;&nbsp;29</span></li>
            </ul>
        </div>
    </div>
    <p class="payWay">支付方式</p>
    <div class="wechat payWayItem" id="wechat">
        <div class="clearfix">
            <div class="chat fl">
                <img src="./imges/icon7.png" /><span>微信支付</span>
                <p>推荐安装微信5.0以及以上版本使用</p>
            </div>
            <img class="selIcon fr">
        </div>
    </div>
    <?php if($row['s_pay']=='s_pzfb'){
        echo "    <div class=\"wechat payWayItem\" id=\"alipay\">
        <div class=\"clearfix\">
            <div class=\"chat fl\">
                <img src=\"./imges/zfb.png\" /><span>支付宝支付</span>
                <p>推荐安装支付宝9.0以及以上版本使用</p>
            </div>
            <img class=\"selIcon fr\">
        </div>
    </div>";
    }

    ?>

</div>
<div class="fixFoot clearfix">
    <p class="total fl">合计：<span>&yen;&nbsp;<em><?php echo $row['s_jg']; ?></em></span></p>
    <a class="submitBtn fr" id='id2'>确认下单</a>		</div>
<!--tip-->
<div class="mask">
    <div class="maskCon maskCon2">
        <h3>提醒</h3>
        <p>您选择验机服务后，优品会为您提供30天质保服务，质检服务要求卖家将物品寄往质检平台检测，请勿向卖家透露您的收货地址，如卖家将手机私自寄往您的地址，为避免纠纷，请原封退还卖家。
        </p>
        <input type="button" value="我知道了" />
    </div>		</div>
<script>
    $(function(){
        $(".check").click(function(){
            if($(this).hasClass("active")){
                $(this).removeClass("active");
            }else{
                $(this).addClass("active");
            }
        });
        $("#id2").click(function(){
            $(".mask").fadeIn("fast");
        });
        $("#id1").click(function(){
            $(".mask").fadeIn("fast");
        });
        $(".maskCon1 input").click(function(){
            $(".mask").fadeOut("fast");
            window.location.href="/index.php?s=/home/index/number.html";
        })
        $(".maskCon2 input").click(function(){
            $(".mask").fadeOut("fast");
            $('.blackBox').show();
            setTimeout(function(){
                $('.blackBox').hide();//找到对应的标签隐藏
            },2500)
        })
    })
</script>
</body>
</html>