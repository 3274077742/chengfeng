<?php
$tpm = $_GET['tpm'];
require "../config.php";
$row = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `shop` WHERE `s_pzfb` = '$tpm'"));
$uid = $row['s_uid'];
$imgdz='../uploads/'.$tpm;
include_once('./lib/QrReader.php');
$qrcode = new QrReader($imgdz);  //图片路径
$text = $qrcode->text();
  $zlink=mysqli_query($mysql_link,"UPDATE `shop` SET `s_zfblink` = '$text' WHERE `shop`.`s_uid` = $uid;");
if($zlink){
    mysqli_close($mysql_link);
    echo "<script language=\"javascript\">
  alert(\"生成成功，返回浏览页\");
  document.location.href=\"../admin2/shoplist.php\";
</script>";
    exit;
}else{
    mysqli_close($mysql_link);
    echo "<script language=\"javascript\">
  alert(\"生成失败，返回浏览页\");
  document.location.href=\"../admin2/shoplist.php\";
</script>";
    exit;
}
?>