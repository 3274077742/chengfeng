<?php
	include_once("./config.php");
	$bill_no   = $_POST['bill_no'];	//订单号码
	$orderNo   = $_POST['orderNo'];	//平台订单号
	$User_no   = $apiName;	//商户号
	$accDate   = $_POST['accDate'];	//支付时间
	$tradeDate = $_POST['tradeDate'];	//商户订单日期
	$money     = $_POST['money'];		//支付金额
	$orderStatus=$_POST["orderStatus"];	//订单状态
	$sign 	   = $_POST['signMsg'];		//签名数据
	
	$user_key = $apikey;	//商户密钥
	/*****************生成签名数据**********************/
	$signStr= "";
	$signStr = $signStr."accDate=".$accDate."&";
	$signStr = $signStr."bill_no=".$bill_no."&";
	$signStr = $signStr."money=".$money."&";
	$signStr = $signStr."orderNo=".$orderNo."&";
	$signStr = $signStr."orderStatus=".$orderStatus."&";
	$signStr = $signStr."tradeDate=".$tradeDate."&";
	$signStr = $signStr."User_no=".$User_no."&";
	$signature = MD5($signStr.$user_key);
	/********************验证签名数据**************************/
	if (strcasecmp($sign, $signature) == 0){
		echo "支付成功".'<br>';
		echo "商户订单号 ".$bill_no.'<br>';
		echo "平台支付订单号 ".$orderNo.'<br>';
		echo "支付金额 ".$money."元".'<br>';
		echo "订单状态 ".$orderStatus;
	}else{
		echo "验证签名失败";
		return false;
	}