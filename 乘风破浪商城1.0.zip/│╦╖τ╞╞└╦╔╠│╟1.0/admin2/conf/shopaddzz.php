
<?php
session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
    $s_mz=$_POST['s_mz'];
$s_jg=$_POST['s_jg'];
$s_mjmz=$_POST['s_mjmz'];
$s_zt=$_POST['s_zt'];
$s_pay=$_POST['s_pay'];
$s_djl=$_POST['s_djl'];
$s_ys=$_POST['s_ys'];
$s_nc=$_POST['s_nc'];
$s_qd=$_POST['s_qd'];
$s_dq=$_POST['s_dq'];
$s_js=$_POST['s_js'];
$s_zssl=$_POST['s_zssl'];
$s_jysl=$_POST['s_jysl'];
$s_hfl=$_POST['s_hfl'];


    $yhm = $_SESSION["UserName"];

    require_once "./common.func.php";
    require_once "./upload.function1.php";
    $files = getFiles();
    foreach ($files as $fileInfo){
        $res =uploadFile($fileInfo);

        @$uploadFiles[]=$res['dest'];
    }
    $img1=basename(@$uploadFiles[0]);
    $img2=basename(@$uploadFiles[1]);
    $img3=basename(@$uploadFiles[2]);
    $img4=basename(@$uploadFiles[3]);
    $img5=basename(@$uploadFiles[4]);
    $s_mjtx=basename(@$uploadFiles[5]);
    $s_paytp=basename(@$uploadFiles[6]);

    if($s_pay==1){
        $s_pay='s_pwx';
    }else{
        $s_pay='s_pzfb';
    }
    require_once "../../config.php";
    $row = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$yhm'"));
    $adzzshop="INSERT INTO `shop` (`s_uid`, `s_pid`, `s_leibie`, `s_mjmz`, `s_mz`, `s_jg`, `s_zt`, `s_pay`, `s_djl`, `s_ys`, `s_nc`, `s_qd`, `s_dq`, `s_js`, `s_zssl`, `s_jysl`, `s_hfl`, `s_tp1`, `s_tp2`, `s_tp3`, `s_tp4`, `s_tp5`, `s_mjtx`, `$s_pay`) VALUES (NULL,  '$row[0]','1', '$s_mjmz', '$s_mz', '$s_jg', '$s_zt', '$s_pay', '$s_djl', '$s_ys', '$s_nc', '$s_qd', '$s_dq', '$s_js', '$s_zssl', '$s_jysl', '$s_hfl', '$img1', '$img2', '$img3', '$img4', '$img5', '$s_mjtx', '$s_paytp')";



    if(mysqli_query($mysql_link,$adzzshop)){

        if($s_pay=='s_pzfb'){
            
            $ym=$_SERVER['SERVER_NAME'];
            echo "<a href='http://$ym/imgapi/tp.php?tpm=$s_paytp'>点击生成支付宝链接</a>";
        }else{
            echo "<script language=\"javascript\">
  alert(\"增加商品成功，返回继续浏览\");
  document.location.href=\"../shoplist.php\";
</script>";}
        exit;
    }else{
        echo "<script language=\"javascript\">
  alert(\"增加商品失败'</br>'\");
  document.location.href=\"../shoplist.php\";
</script>";
        exit;
    }

?>


