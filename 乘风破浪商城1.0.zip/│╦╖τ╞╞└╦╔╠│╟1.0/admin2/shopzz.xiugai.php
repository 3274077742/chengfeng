<?php

session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<?php
    require_once '../config.php';
    $uid=$_GET['uid'];
    $row = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM shop WHERE s_uid = '$uid'"));

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>乘风破浪1.0后台-修改商品</title>
    <link href="./bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="row">
    <div class="col-md-12">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="#">
                                <img alt="Brand" src="./logo.png" width="35px" height="30px">
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="index.php">后台首页 <span class="sr-only">(current)</span></a></li>
                        <?php
                        require "../config.php";
                        $adpid = $_SESSION["UserName"];
                        $rowpid = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$adpid'"));
                        if($rowpid['Pid']==1){
                            echo "<li><a href=\"./user.php\">用户管理</a></li><li><a href=\"./shapi.php\">商户信息</a></li>";
                            mysqli_close($mysql_link);
                        }
                        ?>
                        <li><a href="./rmuser.php">修改密码</a></li>
                        <li><a href="./shoplist.php">查看商品</a></li>
                        <li><a href="./showdd.php">订单查看</a></li>
                        <li><a href="./ad.php">发布商品</a></li>

                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">管理员：<?php echo $_SESSION["UserName"]; ?></a></li>
                        <li><a href="./conf/zhuxiaologin.php">注销登录</a></li>

                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">

            <div class="list-group" style="text-align: center">
                <a href="#" class="list-group-item active">
                    修改商品
                </a>
                <form action="./conf/xiugaizzshop.php?uid=<?php echo $uid; ?>" enctype="multipart/form-data" method="post">
                    <ul class="list-group">
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">所属类别</span>
                            <input class="form-control" id="disabledInput" type="text" placeholder="转转手机类" disabled>
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                                <span class="input-group-addon" id="sizing-addon2">商品名称</span>
                                <input type="text" name="s_mz" class="form-control" placeholder="商品名称" value="<?php echo $row['s_mz']; ?>" aria-describedby="sizing-addon2">
                            </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">商品价格</span>
                            <input type="text" name="s_jg" class="form-control" value="<?php echo $row['s_jg']; ?>" placeholder="商品价格" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">卖家名称</span>
                            <input type="text" name="s_mjmz" class="form-control" value="<?php echo $row['s_mjmz']; ?>" placeholder="卖家名称" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="form-group">

                            <div class="dhna" style="float: left">

                                <select name="s_zt" class="" style="width: 150px;text-align: center" >
                                        <?php
                                            if($row['s_zt']==1){
                                                echo "<option value=\"1\">上架</option>
                                    <option value=\"2\">下架</option>";
                                            }else{
                                                echo "<option value=\"2\">下架</option>
                                            <option value=\"1\">上架</option>";
                                            }

                                        ?>


                                </select>
                            </div>
                            <div class="a4454" style="float: right">

                                <select name="s_pay" class="" style="width: 150px;text-align: center">
                                    <?php
                                    if($row['s_pay']=='s_pwx'){

                                                echo "<option value=\"1\">微信</option>
                                    <option value=\"2\">支付宝</option>";
                                            }else{
                                                echo "<option value=\"2\">支付宝</option>
                                            <option value=\"1\">微信</option>";
                                            }

                                    ?>

                                </select>
                            </div>
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">点击量</span>
                            <input type="text" name="s_djl" value="<?php echo $row['s_djl']; ?>" class="form-control" placeholder="点击量" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">商品颜色</span>
                            <input type="text" name="s_ys" value="<?php echo $row['s_ys']; ?>" class="form-control" placeholder="商品颜色" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">商品内存</span>
                            <input type="text" name="s_nc" class="form-control" value="<?php echo $row['s_nc']; ?>" placeholder="商品内存" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">购买渠道</span>
                            <input type="text" name="s_qd" class="form-control" value="<?php echo $row['s_qd']; ?>" placeholder="购买渠道" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">所在地区</span>
                            <input type="text" name="s_dq" class="form-control" value="<?php echo $row['s_dq']; ?>" placeholder="所在地区" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">商品介绍</span>
                            <textarea  name="s_js" class="form-control"rows="3"><?php echo $row['s_js']; ?> </textarea>
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">在售宝贝数量</span>
                            <input type="text" name="s_zssl" class="form-control" value="<?php echo $row['s_zssl']; ?>" placeholder="必须填写数字：例如1" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">累计交易数量</span>
                            <input type="text" name="s_jysl" class="form-control" value="<?php echo $row['s_jysl']; ?>" placeholder="必须填写数字，例如1" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">商品回复率%</span>
                            <input type="text" name="s_hfl" class="form-control" value="<?php echo $row['s_hfl']; ?>" placeholder="必须填数字，90,100此类型" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <div class="row">
                                <?php
                                if($row['s_tp1']!=''){
                                    echo "<div class=\"col-xs-6 col-md-3\">
                                    
                                        <img src=\"../uploads/{$row['s_tp1']}\" alt=\"...\" width=\"80px\" height=\"80px\" >
                                </div>";
                                }
                                ?>

                            </div>
                            <label for="exampleInputFile"><a href="./conf/shopzz.scimg.php?uid=<?php echo $uid;?>&i=s_tp1">删除图片</a>&nbsp;&nbsp;商品主图，不上传不修改/上传替换</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <div class="row">
                                <?php
                                if($row['s_tp2']!=''){
                                    echo "<div class=\"col-xs-6 col-md-3\">
                                    
                                        <img src=\"../uploads/{$row['s_tp2']}\" alt=\"...\" width=\"80px\" height=\"80px\" >
                                </div>";
                                }
                                ?>
                            </div>
                            <label for="exampleInputFile"><a href="./conf/shopzz.scimg.php?uid=<?php echo $uid;?>&i=s_tp2">删除图片</a>&nbsp;&nbsp;商品第二张图片，不上传不修改/上传替换</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <div class="row">
                                <?php
                                if($row['s_tp3']!=''){
                                    echo "<div class=\"col-xs-6 col-md-3\">
                                    
                                        <img src=\"../uploads/{$row['s_tp3']}\" alt=\"...\" width=\"80px\" height=\"80px\" >
                                </div>";
                                }
                                ?>
                            </div>
                            <label for="exampleInputFile"><a href="./conf/shopzz.scimg.php?uid=<?php echo $uid;?>&i=s_tp3">删除图片</a>&nbsp;&nbsp;商品第三张图片，不上传不修改/上传替换</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <div class="row">
                                <?php
                                if($row['s_tp4']!=''){
                                    echo "<div class=\"col-xs-6 col-md-3\">
                                    
                                        <img src=\"../uploads/{$row['s_tp4']}\" alt=\"...\" width=\"80px\" height=\"80px\" >
                                </div>";
                                }
                                ?>
                            </div>
                            <label for="exampleInputFile"><a href="./conf/shopzz.scimg.php?uid=<?php echo $uid;?>&i=s_tp4">删除图片</a>&nbsp;&nbsp;商品第四张图片，不上传不修改/上传替换</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <div class="row">
                                <?php
                                if($row['s_tp5']!=''){
                                    echo "<div class=\"col-xs-6 col-md-3\">
                                    
                                        <img src=\"../uploads/{$row['s_tp5']}\" alt=\"...\" width=\"80px\" height=\"80px\" >
                                </div>";
                                }
                                ?>
                            </div>
                            <label for="exampleInputFile"><a href="./conf/shopzz.scimg.php?uid=<?php echo $uid;?>&i=s_tp5">删除图片</a>&nbsp;&nbsp;商品第五张图片，不上传不修改/上传替换</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <div class="row">
                                <?php
                                if($row['s_mjtx']!=''){
                                    echo "<div class=\"col-xs-6 col-md-3\">
                                    
                                        <img src=\"../uploads/{$row['s_mjtx']}\" alt=\"...\" width=\"80px\" height=\"80px\" >
                                </div>";
                                }
                                ?>
                            </div>

                            <label for="exampleInputFile"><a href="./conf/shopzz.scimg.php?uid=<?php echo $uid;?>&i=s_mjtx">删除图片</a>&nbsp;&nbsp;卖家头像图片，不上传不修改/上传替换</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <div class="row">
                                <?php
                                if($row['s_pay']=='s_pwx')
                                {
                                    $imgpay =$row['s_pwx'];
                                }
                                else{
                                    $imgpay =$row['s_pzfb']; }
                                if($imgpay!=''){
                                    echo "<div class=\"col-xs-6 col-md-3\">
                                    
                                        <img src=\"../uploads/$imgpay\" alt=\"...\" width=\"80px\" height=\"80px\" >
                                </div>";
                                }

                                    ?>

                            </div>
                            <label for="exampleInputFile"><a href="./conf/shopzz.scimg.php?uid=<?php echo $uid; ?>&i=skt">删除图片</a>&nbsp;&nbsp;卖家收款图片，不上传不修改/上传替换</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><button type="submit" class="btn btn-info">确认修改</button></li>

                    </ul>
                </form>
            </div>
        </div>
    </div>
</div>


<?php

require "./dibu..inc.php";

?>


<script src="./jquery-3.2.1/jquery-3.2.1.js"></script>
<script src="./bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>