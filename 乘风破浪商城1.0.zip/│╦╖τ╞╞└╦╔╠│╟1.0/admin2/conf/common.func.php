<?php
/**
 * 得到文件唯一文件名；
 */
    function getExt($filename){
        return strtolower(pathinfo($filename,PATHINFO_EXTENSION));
    }

/**
 * @return string产生唯一字符串，当做我的文件名
 */
    function getUniName(){
        return md5(uniqid(microtime(true),true));
    }

?>