<?php

session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
require "../config.php";
$pageSize = 5;
$cxshop=mysqli_query($mysql_link,"SELECT count(*) from shop");
$sprest=mysqli_fetch_row($cxshop);
$pageCount= ceil($sprest['0']/$pageSize);
$currpage = empty($_GET['page'])?1:$_GET['page'];
if($currpage>$pageSize){
    $currpage=1;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>乘风破浪1.0后台-商品列表</title>
    <link href="./bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="row">
    <div class="col-md-12">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="#">
                                <img alt="Brand" src="./logo.png" width="35px" height="30px">
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li ><a href="index.php">后台首页 </a></li>
                        <?php
                        require '../config.php';
                        $adpid = $_SESSION["UserName"];

                        $rowpid = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$adpid'"));
                        if($rowpid['Pid']==1){
                            echo "<li><a href=\"./user.php\">用户管理</a></li><li><a href=\"./shapi.php\">商户信息</a></li>";

                        }
                        ?>
                        <li><a href="./rmuser.php">修改密码</a></li>
                        <li class="active"><a href="#">查看商品<span class="sr-only">(current)</span></a></li>
                        <li><a href="./showdd.php">订单查看</a></li>
                        <li><a href="./ad.php">发布商品</a></li>

                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">管理员：<?php echo $_SESSION["UserName"]; ?></a></li>
                        <li><a href="./conf/zhuxiaologin.php">注销登录</a></li>

                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="list-group" style="text-align: center">



                                    <?php
                                    $ssion=$_SESSION["UserName"];
                                    $rowcxpid =mysqli_fetch_row(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$ssion'"));
                                    if($rowcxpid['1']==1){

                                    echo "
<a href=\"#\" class=\"list-group-item active\" style=\"font-size: 20px\">
                  商品统计：共$sprest[0]件
                </a>
                <ul class=\"list-group\">
                    <li class=\"list-group-item\">
                        <div class=\"table-responsive\">
                            <table class=\"table\">
<tr>
                                    <td class=\"active\" style=\"text-align: center\">ID</td>
                                    <td class=\"success\" style=\"text-align: center\">用户</td>
                                    <td class=\"warning\" style=\"text-align: center\">商品名称</td>
                                    <td class=\"warning\" style=\"text-align: center\">类型</td>
                                    <td class=\"info\" style=\"text-align: center\">卖家名称</td>
                                    <td class=\"info\" style=\"text-align: center\">上架</td>
                                    <td class=\"info\" style=\"text-align: center\">产品页</td>
                                    <td class=\"info\" style=\"text-align: center\">浏览量</td>
                                    <td class=\"info\" style=\"text-align: center\">操作</td>
                                </tr>";
              $spsql = "SELECT * FROM shop limit ".($currpage-1)*$pageSize.",".$pageSize;
              $spcx = mysqli_query($mysql_link,$spsql);
              while($rowsp = mysqli_fetch_array($spcx)){
                  $restsp1[] = $rowsp;
              }
              if(@$restsp1!=null){
              foreach ($restsp1 as $key=>$rowsp) {
                $s_uid=$rowsp['s_uid'];
                $s_pid=$rowsp['s_pid'];
                $cyhm = mysqli_fetch_row(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE UID='$s_pid'"));
                switch ($cyhm[2]){
                    case null:
                        $yhm = '用户已被删除';
                        break;
                    default:
                        $yhm=$cyhm[2];
                }

                $s_leibie=$rowsp['s_leibie'];
                  switch ($s_leibie){
                      case 1:
                          $s_leibie="转转";
                          $leibie="zz";
                          break;
                      case 2:
                          $s_leibie="咸鱼";
                          $leibie="xy";
                          break;
                      case 3:
                          $s_leibie="游戏";
                          $leibie="yx";
                          break;
                      case 4:
                          $s_leibie="猎趣";
                          $leibie="liequ";
                          break;
                      default:
                          $s_leibie="没有此类商品";
                          $leibie="没有此类商品";
                  }
                $s_mz=$rowsp['s_mz'];
                $s_mjmz=$rowsp['s_mjmz'];
                $s_zt=$rowsp['s_zt'];
                $s_djl=$rowsp['s_djl'];

                if($s_zt==1){

                    echo "<tr><td class=\"\" style=\"text-align: center\">$s_uid</td>
                                    <td class=\"\" style=\"text-align: center\">$yhm</td>
                                    <td class=\"\" style=\"text-align: center\">$s_mz</td>
                                    <td class=\"\" style=\"text-align: center\">$s_leibie</td>
                                    <td class=\"\" style=\"text-align: center\">$s_mjmz</td>
                                    <td class=\"\" style=\"text-align: center \">是|<a href='./conf/xiugaizt.php?uid=$s_uid&zt=2' >否</a></td>
                                    <td class=\"\" style=\"text-align: center\"><a href='../$leibie/index.php?uid=$s_uid&zt=$s_zt'>商品页</a> </td>
                                    <td class=\"\" style=\"text-align: center\">$s_djl</td>
                                    <td class=\"\" style=\"text-align: center\"><a href='./shopzz.xiugai.php?uid=$s_uid'>改</a> |<a href='./conf/scshop.php?uid=$s_uid'>删</a></td></tr>";
                }else{
                    echo "<tr><td class=\"\" style=\"text-align: center\">$s_uid</td>
                                    <td class=\"\" style=\"text-align: center\">$yhm</td>
                                    <td class=\"\" style=\"text-align: center\">$s_mz</td>
                                    <td class=\"\" style=\"text-align: center\">$s_leibie</td>
                                    <td class=\"\" style=\"text-align: center\">$s_mjmz</td>
                                    <td class=\"\" style=\"text-align: center\"><a href='./conf/xiugaizt.php?uid=$s_uid&zt=1' >是</a>|否</td>
                                    <td class=\"\" style=\"text-align: center\"><a href='../$leibie/index.php?uid=$s_uid&zt=$s_zt'>商品页</a> </td>
                                    <td class=\"\" style=\"text-align: center\">$s_djl</td>
                                    <td class=\"\" style=\"text-align: center\"><a href='./shopzz.xiugai.php?uid=$s_uid'>改</a> |<a href='./conf/scshop.php?uid=$s_uid'>删</a></td></tr>";
                }
              }

              }}else{

                                        $cxshopyh=mysqli_query($mysql_link,"SELECT count(*) from shop WHERE `s_pid` = $rowcxpid[0]");
                                        @$yhsprest=mysqli_fetch_row($cxshopyh);
                                        if($yhsprest[0]==null){
                                            $yhsprest[0]=0;
                                        }
                                        $pageCount= ceil($yhsprest['0']/$pageSize);
                                        $currpage = empty($_GET['page'])?1:$_GET['page'];
                                        if($currpage>$pageSize){
                                            $currpage=1;
                                        }
                                        echo "
<a href=\"#\" class=\"list-group-item active\" style=\"font-size: 20px\">
                  商品统计：共$yhsprest[0]件
                </a>
                <ul class=\"list-group\">
                    <li class=\"list-group-item\">
                        <div class=\"table-responsive\">
                            <table class=\"table\">
<tr>
                                    <td class=\"active\" style=\"text-align: center\">ID</td>
                                    <td class=\"warning\" style=\"text-align: center\">商品名称</td>
                                    <td class=\"warning\" style=\"text-align: center\">类型</td>
                                    <td class=\"info\" style=\"text-align: center\">卖家名称</td>
                                    <td class=\"info\" style=\"text-align: center\">上架</td>
                                    <td class=\"info\" style=\"text-align: center\">产品页</td>
                                    <td class=\"info\" style=\"text-align: center\">浏览量</td>
                                    <td class=\"info\" style=\"text-align: center\">操作</td>
                                </tr>";
                                        $yhspsql = "SELECT * FROM shop WHERE `s_pid` = $rowcxpid[0] limit ".($currpage-1)*$pageSize.",".$pageSize;
                                        $yhspcx = mysqli_query($mysql_link,$yhspsql);
                                        while($yhrowsp = mysqli_fetch_array($yhspcx)){
                                            $yhrestsp1[] = $yhrowsp;
                                        }
                                        if(@$yhrestsp1!=null){
                                            foreach ($yhrestsp1 as $key=>$yhrowsp) {
                                                $s_uid=$yhrowsp['s_uid'];
                                                $s_pid=$yhrowsp['s_pid'];
                                                $cyhm = mysqli_fetch_row(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE UID='$s_pid'"));
                                                switch ($cyhm[2]){
                                                    case null:
                                                        $yhm = '用户已被删除';
                                                        break;
                                                    default:
                                                        $yhm=$cyhm[2];
                                                }

                                                $s_leibie=$yhrowsp['s_leibie'];
                                                switch ($s_leibie){
                                                    case 1:
                                                        $s_leibie="转转";
                                                        $leibie="zz";
                                                        break;
                                                    case 2:
                                                        $s_leibie="咸鱼";
                                                        $leibie="xy";
                                                        break;
                                                    case 3:
                                                        $s_leibie="游戏";
                                                        $leibie="yx";
                                                        break;
                                                    case 4:
                                                        $s_leibie="猎趣";
                                                        $leibie="liequ";
                                                        break;
                                                    default:
                                                        $s_leibie="没有此类商品";
                                                        $leibie="没有此类商品";
                                                }

                                                $s_mz=$yhrowsp['s_mz'];
                                                $s_mjmz=$yhrowsp['s_mjmz'];
                                                $s_zt=$yhrowsp['s_zt'];
                                                $s_djl=$yhrowsp['s_djl'];

                                                if($s_zt==1){

                                                    echo "<tr><td class=\"\" style=\"text-align: center\">$s_uid</td>
                                    <td class=\"\" style=\"text-align: center\">$s_mz</td>
                                    <td class=\"\" style=\"text-align: center\">$s_leibie</td>
                                    <td class=\"\" style=\"text-align: center\">$s_mjmz</td>
                                    <td class=\"\" style=\"text-align: center\">是|<a href='./conf/xiugaizt.php?uid=$s_uid&zt=2' >否</a></td>
                                    <td class=\"\" style=\"text-align: center\"><a href='../$leibie/index.php?uid=$s_uid&zt=$s_zt'>商品页</a> </td>
                                    <td class=\"\" style=\"text-align: center\">$s_djl</td>
                                    <td class=\"\" style=\"text-align: center\"><a href='./shopzz.xiugai.php?uid=$s_uid'>改</a> |<a href='./conf/scshop.php?uid=$s_uid'>删</a></td></tr>";
                                                }else{
                                                    echo "<tr><td class=\"\" style=\"text-align: center\">$s_uid</td>
                                    <td class=\"\" style=\"text-align: center\">$s_mz</td>
                                    <td class=\"\" style=\"text-align: center\">$s_leibie</td>
                                    <td class=\"\" style=\"text-align: center\">$s_mjmz</td>
                                    <td class=\"\" style=\"text-align: center\"><a href='' ><a href='./conf/xiugaizt.php?uid=$s_uid&zt=1' >是</a>|否</td>
                                    <td class=\"\" style=\"text-align: center\"><a href='../$leibie/index.php?uid=$s_uid&zt=$s_zt'>商品页</a> </td>
                                    <td class=\"\" style=\"text-align: center\">$s_djl</td>
                                    <td class=\"\" style=\"text-align: center\"><a href='./shopzz.xiugai.php?uid=$s_uid'>改</a> |<a href='./conf/scshop.php?uid=$s_uid'>删</a></td></tr>";
                                                }
                                            }

                                        }

                                    }
                  ?>

                            </table>
                        </div>
                        <ul class="pagination">
                            <?php
                            if($rowpid['Pid']==1){
                                @$page=$_GET['page'];
                                if($page==0){
                                    echo "<li>
                                <a href=\"#\" aria-label=\"Previous\">
                                    <span aria-hidden=\"true\">&laquo;</span>
                                </a>
                            </li>";
                                }else{
                                    $page1=$page-1;
                                    echo "<li>
                                <a href=\"./shoplist.php?page=$page1\" aria-label=\"Previous\">
                                    <span aria-hidden=\"true\">&laquo;</span>
                                </a>
                            </li>";
                                }
                                for($i=1;$i<=$pageCount;$i++){
                                    if($i==$page){
                                        echo "<li class=\"active\"><span>$i<span class=\"sr-only\">(current)</span></span></li>";
                                    }else{
                                        echo "<li><a href=\"./shoplist.php?page=$i\">$i</a></li>";
                                    }
                                }
                                if($page>=$pageCount){
                                    echo "<li>
                                <a href=\"#\" aria-label=\"Next\">
                                    <span aria-hidden=\"true\">&raquo;</span>
                                </a>
                            </li>";
                                }else{
                                    $page2=$page+1;
                                    echo "<li>
                                <a href=\"./shoplist.php?page=$page2\" aria-label=\"Next\">
                                    <span aria-hidden=\"true\">&raquo;</span>
                                </a>
                            </li>";
                                }
                            }else{
                                @$page=$_GET['page'];
                                if($page==0){
                                    echo "<li>
                                <a href=\"#\" aria-label=\"Previous\">
                                    <span aria-hidden=\"true\">&laquo;</span>
                                </a>
                            </li>";
                                }else{
                                    $page1=$page-1;
                                    echo "<li>
                                <a href=\"./shoplist.php?page=$page1\" aria-label=\"Previous\">
                                    <span aria-hidden=\"true\">&laquo;</span>
                                </a>
                            </li>";
                                }
                                for($i=1;$i<=$pageCount;$i++){
                                    if($i==$page){
                                        echo "<li class=\"active\"><span>$i<span class=\"sr-only\">(current)</span></span></li>";
                                    }else{
                                        echo "<li><a href=\"./shoplist.php?page=$i\">$i</a></li>";
                                    }
                                }
                                if($page>=$pageCount){
                                    echo "<li>
                                <a href=\"#\" aria-label=\"Next\">
                                    <span aria-hidden=\"true\">&raquo;</span>
                                </a>
                            </li>";
                                }else{
                                    $page2=$page+1;
                                    echo "<li>
                                <a href=\"./shoplist.php?page=$page2\" aria-label=\"Next\">
                                    <span aria-hidden=\"true\">&raquo;</span>
                                </a>
                            </li>";
                                }

                            }
                            ?>

                        </ul>
                        </nav>
                    </li>

                </ul>
            </div>
        </div>

    </div>
</div>


<div class="container">
    <div class="row">
        <div class="col-md-12">

            <div class="list-group" >
                <div class="mnih" style="text-align: center">
                <a href="#" class="list-group-item active">
                    新增商品
                </a>
                </div>
                <?php
                if($rowcxpid['1']==1){
                    echo "<a href=\"./adshopzz.php\" class=\"list-group-item\"><span class=\"badge\">全站商品共$sprest[0]个</span>转转</a>";
                }else{
                    echo "<a href=\"./adshopzz.php\" class=\"list-group-item\"><span class=\"badge\">您的商品共$yhsprest[0]个</span>转转</a>";
                }
                    ?>

                <a href="#" class="list-group-item" ><span class="badge">14</span>闲鱼商品</a>
                <a href="#" class="list-group-item"><span class="badge">14</span>猎趣商品</a>
                <a href="#" class="list-group-item"><span class="badge">14</span>游戏商品</a>
            </div>




        </div>
    </div>

</div>
<?php
require "./dibu..inc.php";

?>
<script src="./jquery-3.2.1/jquery-3.2.1.js"></script>
<script src="./bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>