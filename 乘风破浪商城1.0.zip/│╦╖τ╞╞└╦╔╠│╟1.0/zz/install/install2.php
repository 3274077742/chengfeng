<?php
            $panduan = file_exists("install.lok");
            if($panduan){
                exit("请勿重复安装");
            }
            $sql1 = "CREATE TABLE adminuser (
              uid int(11) unsigned NOT NULL AUTO_INCREMENT,
              pid int(11) NOT NULL DEFAULT '1',
              ad_user TEXT NOT NULL DEFAULT '',
              ad_pws varchar(32) NOT NULL DEFAULT '',
              ad_mail TEXT NOT NULL DEFAULT '',
              PRIMARY KEY (`uid`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ; ";
            $sql2="CREATE TABLE shouhuo (
              sh_id int(11) unsigned NOT NULL AUTO_INCREMENT,
              sh_ip TEXT NOT NULL DEFAULT '',
              sh_dd TEXT NOT NULL DEFAULT '',
              sh_name TEXT NOT NULL DEFAULT '',
              sh_cp TEXT NOT NULL DEFAULT '',
              sh_phone TEXT NOT NULL DEFAULT '',
              sh_youbian TEXT NOT NULL DEFAULT '',
              sh_diqu TEXT NOT NULL DEFAULT '',
              sh_xiangxi TEXT NOT NULL DEFAULT '',
              PRIMARY KEY (`sh_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";

                $sql3 = "CREATE TABLE shop (
              id int(11) unsigned NOT NULL AUTO_INCREMENT,
              shop_name TEXT NOT NULL DEFAULT '',
              shop_jg INT(12) NOT NULL DEFAULT '0',
              shop_js TEXT NOT NULL DEFAULT '',
              shop_img1 TEXT NOT NULL DEFAULT '',
              shop_img2 TEXT NOT NULL DEFAULT '',
              shop_img3 TEXT NOT NULL DEFAULT '',
              shop_zt INT(11) NOT NULL DEFAULT '1',
              pay_id INT(11) NOT NULL DEFAULT '1',
              shop_paywx TEXT NOT NULL DEFAULT '',
              shop_payzfb TEXT NOT NULL DEFAULT '',
              shop_mjtx TEXT NOT NULL DEFAULT '',
              shop_mjname TEXT NOT NULL DEFAULT '',
              shop_liulan TEXT NOT NULL DEFAULT '',
              shop_clor TEXT NOT NULL DEFAULT '',
              shop_neicun TEXT NOT NULL DEFAULT '',
              shop_goumai TEXT NOT NULL DEFAULT '',
              shop_diqu TEXT NOT NULL DEFAULT '',
              PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" ;
            $link = mysqli_connect('localhost','root','','456789');
            if($link){
                mysqli_select_db($link,"456789");
                $jianbiao1 = mysqli_query($link,"$sql1");
                $jianbiao2 = mysqli_query($link,"$sql2");
                $jianbiao3 = mysqli_query($link,"$sql3");
                $xiugai = mysqli_query($link,"ALTER TABLE `shop` CHANGE `shop_mjname` `shop-mjname` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL");
                if ($xiugai){
                    echo "修改成功";

                }                if($jianbiao1){
                                  echo "建立成功1";

                                }else{
                                        echo '建立失败1';
                                    }if($jianbiao2){
                    echo "建立成功3";

                }else{
                    echo '建立失败2';
                }
                if($jianbiao2){
                    echo "建立成功3";

                }else{
                    echo '建立失败3';
                }
                exit;

                                }else{
                                    exit('连接失败');
                                }

?>