<?php

session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<?php
    require "../config.php";
    $pageSize = 5;
    $cxdd=mysqli_query($mysql_link,"SELECT count(*) from dingdan");
    $ddrest=mysqli_fetch_row($cxdd);
    $pageCount= ceil($ddrest['0']/$pageSize);
    $currpage = empty($_GET['page'])?1:$_GET['page'];
    if($currpage>$pageSize){
        $currpage=1;
    }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>乘风破浪1.0后台-商品列表</title>
    <link href="./bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="row">
    <div class="col-md-12">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="#">
                                <img alt="Brand" src="./logo.png" width="35px" height="30px">
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">后台首页</a></li>
                        <?php
                        require "../config.php";
                        $adpid = $_SESSION["UserName"];
                        $rowpid = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$adpid'"));
                        if($rowpid['Pid']==1){
                            echo "<li><a href=\"./user.php\">用户管理</a></li><li><a href=\"./shapi.php\">商户信息</a></li>";

                        }
                        ?>
                        <li><a href="./rmuser.php">修改密码</a></li>
                        <li><a href="./shoplist.php">查看商品</a></li>
                        <li class="active"><a href="#">订单查看<span class="sr-only">(current)</span></a></li>
                        <li><a href="./ad.php">发布商品</a></li>

                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">管理员：<?php echo $_SESSION["UserName"]; ?></a></li>
                        <li><a href="./conf/zhuxiaologin.php">注销登录</a></li>

                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">

            <div class="list-group" >
                <div class="mnih" style="text-align: center">
                    <a href="#" class="list-group-item active" style="font-size: 20px">
                        全站商品订单统计，共<?php echo $ddrest['0'];?>条
                    </a>
                </div>
                <a href="#" class="list-group-item"><span class="badge">全站共<?php echo $ddrest['0'];?>条</span>转转商品订单</a>
                <a href="#" class="list-group-item"><span class="badge">全站共14条</span>闲鱼商品订单</a>
                <a href="#" class="list-group-item"><span class="badge">全站共14条</span>猎趣商品订单</a>
                <a href="#" class="list-group-item"><span class="badge">全站共14条</span>游戏商品订单</a>
            </div>




        </div>
    </div>

</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="list-group" style="text-align: center">
                <a href="#" class="list-group-item active" >
                    您的订单详情
                </a>
                <ul class="list-group">
                    <li class="list-group-item">
                        <div class="table-responsive">
                            <table class="table">

                                <tr>
                                    <td class="active" style="text-align: center">ID</td>
                                    <td class="success" style="text-align: center">订单号</td>
                                    <td class="info" style="text-align: center">买家姓名</td>
                                    <td class="warning" style="text-align: center">商品名称</td>
                                    <td class="info" style="text-align: center">商品类别</td>
                                    <td class="warning" style="text-align: center">IP</td>
                                    <td class="success" style="text-align: center">卖家用户名</td>
                                    <td class="info" style="text-align: center">联系方式</td>
                                    <td class="warning" style="text-align: center">收货地区</td>
                                    <td class="info" style="text-align: center">操作</td>
                                </tr>
                                <?php
                                $ssion=$_SESSION["UserName"];
                                $rowcxpid =mysqli_fetch_row(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$ssion'"));
                                if($rowcxpid['1']==1){
                                    $ddsql = "SELECT * FROM dingdan limit ".($currpage-1)*$pageSize.",".$pageSize;
                                    $ddcx = mysqli_query($mysql_link,$ddsql);
                                    while($rowdd = mysqli_fetch_array($ddcx)){
                                        $restdd1[] = $rowdd;}
                                        if(@$restdd1!=null){
                                            foreach ($restdd1 as $key=>$rowdd2){
                                                $spid=$rowdd2['d_pid'];
                                                $rowsp = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `shop` WHERE `s_uid` = $spid"));
                                                $adid=$rowdd2['d_nid'];
                                                $rowad = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `UID` = $adid"));
                                                echo " <tr>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_uid']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_sid']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_name']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowsp['s_mz']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_leibie']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_ip']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowad['adminName']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_phone']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_city']}</td>
                                    <td class=\"\" style=\"text-align: center\"><a href='./conf/scdingdan.php?uid={$rowdd2['d_uid']}'>删除</a> </td>
                                </tr>";
                                            }
                                        }





                                }else{
                                    $ddsql = "SELECT * FROM dingdan WHERE d_nid = $rowcxpid[0] limit ".($currpage-1)*$pageSize.",".$pageSize;
                                    $ddcx = mysqli_query($mysql_link,$ddsql);
                                    while($rowdd = mysqli_fetch_array($ddcx)){
                                        $restdd1[] = $rowdd;}
                                    if(@$restdd1!=null){
                                        foreach ($restdd1 as $key=>$rowdd2){
                                            $spid=$rowdd2['d_pid'];
                                            $rowsp = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `shop` WHERE `s_uid` = $spid"));
                                            $adid=$rowdd2['d_nid'];
                                            $rowad = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `UID` = $adid"));
                                            echo " <tr>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_uid']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_sid']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_name']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowsp['s_mz']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_leibie']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_ip']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowad['adminName']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_phone']}</td>
                                    <td class=\"\" style=\"text-align: center\">{$rowdd2['d_city']}</td>
                                    <td class=\"\" style=\"text-align: center\"><a href='./conf/scdingdan.php?uid={$rowdd2['d_uid']}'>删除</a></td>
                                </tr>";
                                        }
                                    }

                                }

                                ?>
                            </table>
                        </div>
                        <ul class="pagination">

                            <?php
                            if($rowpid['Pid']==1){
                                @$page=$_GET['page'];
                                if($page==0){
                                    echo "<li>
                                <a href=\"#\" aria-label=\"Previous\">
                                    <span aria-hidden=\"true\">&laquo;</span>
                                </a>
                            </li>";
                                }else{
                                    $page1=$page-1;
                                    echo "<li>
                                <a href=\"./showdd.php?page=$page1\" aria-label=\"Previous\">
                                    <span aria-hidden=\"true\">&laquo;</span>
                                </a>
                            </li>";
                                }
                                for($i=1;$i<=$pageCount;$i++){
                                    if($i==$page){
                                        echo "<li class=\"active\"><span>$i<span class=\"sr-only\">(current)</span></span></li>";
                                    }else{
                                        echo "<li><a href=\"./showdd.php?page=$i\">$i</a></li>";
                                    }
                                }
                                if($page>=$pageCount){
                                    echo "<li>
                                <a href=\"#\" aria-label=\"Next\">
                                    <span aria-hidden=\"true\">&raquo;</span>
                                </a>
                            </li>";
                                }else{
                                    $page2=$page+1;
                                    echo "<li>
                                <a href=\"./showdd.php?page=$page2\" aria-label=\"Next\">
                                    <span aria-hidden=\"true\">&raquo;</span>
                                </a>
                            </li>";
                                }
                            }else{
                                @$page=$_GET['page'];
                                if($page==0){
                                    echo "<li>
                                <a href=\"#\" aria-label=\"Previous\">
                                    <span aria-hidden=\"true\">&laquo;</span>
                                </a>
                            </li>";
                                }else{
                                    $page1=$page-1;
                                    echo "<li>
                                <a href=\"./showdd.php?page=$page1\" aria-label=\"Previous\">
                                    <span aria-hidden=\"true\">&laquo;</span>
                                </a>
                            </li>";
                                }
                                for($i=1;$i<=$pageCount;$i++){
                                    if($i==$page){
                                        echo "<li class=\"active\"><span>$i<span class=\"sr-only\">(current)</span></span></li>";
                                    }else{
                                        echo "<li><a href=\"./showdd.php?page=$i\">$i</a></li>";
                                    }
                                }
                                if($page>=$pageCount){
                                    echo "<li>
                                <a href=\"#\" aria-label=\"Next\">
                                    <span aria-hidden=\"true\">&raquo;</span>
                                </a>
                            </li>";
                                }else{
                                    $page2=$page+1;
                                    echo "<li>
                                <a href=\"./showdd.php?page=$page2\" aria-label=\"Next\">
                                    <span aria-hidden=\"true\">&raquo;</span>
                                </a>
                            </li>";
                                }

                            }
                            ?>


                        </ul>
                        </nav>
                    </li>

                </ul>
            </div>
        </div>

    </div>
</div>



<?php
require "./dibu..inc.php";
mysqli_close($mysql_link);
?>
<script src="./jquery-3.2.1/jquery-3.2.1.js"></script>
<script src="./bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>