<?php

$jhgqsj = 1549912293; //一年后
$ym = "www.c.tld";

$gdz1 = '4LbFnUKUsDxyuXXkN7fRK4';
$gdz2 = 'TDBk4szBg7Hcn3svKEdAqw';

$jhjym = sha1($jhgqsj . $gdz1 . $ym . $gdz2);

echo $jhjym;
?>