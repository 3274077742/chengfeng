<?php
$uid=$_GET['uid'];
$ip = $_SERVER["REMOTE_ADDR"];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./js/style.css" />
    <script src="./js/jquery-2.1.0.js" ></script>
    <script src="./js/index.js" ></script>
    <title>新增地址</title>
</head>
<body class="bgColor">
<form action="../admin2/conf/getdd.php" method="post">
    <ul class="personForm">
        <li>
            <label>联系人姓名</label><input type="text" value="" name="d_name" required="required" placeholder="您的姓名"  />
        </li>
        <li>
            <label>手机号码</label><input type="text" value="" name='d_phone' required="required" placeholder="卖家和快递员联系您的方式" />
        </li>
        <li>
            <label>邮政编码</label><input type="text" value="" name="d_youbian"  placeholder="可以不用那么精确" />
        </li>
        <li>
            <label>所在地区</label><input type="text" value="" name="d_city" required="required" placeholder="请输入所在地区：省、市、区" />
        </li>
        <li>
            <label>详细地址</label><input type="text" value="" name="d_tle" required="required"  placeholder="请输入详细的地址信息" />
        </li>
        <input type="hidden" name="ip" value="<?PHP echo $ip; ?>"/>
        <input type="hidden" name="uid" value="<?PHP echo $uid; ?>"/>
    </ul>
    <div class="clearfix">
        <input class="fr reserve" type="submit" value="保存" />
        <!--<input class="fl delete" type="submit" value="删除" />-->
    </div>
</form>
<!--<a href="address.html" class="add">新增地址</a>-->
</body>
</html>