<?php
session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<?php
require_once "../config.php";
$sseion =$_SESSION["UserName"];
$uid = $_GET['uid'];
$row = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `Uid` = '$uid'"));
$row1 = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$sseion'"));
mysqli_close($mysql_link);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>乘风破浪1.0后台-修改密码</title>
    <link href="./bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="row">
    <div class="col-md-12">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="#">
                                <img alt="Brand" src="./logo.png" width="35px" height="30px">
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li ><a href="index.php">后台首页 </a></li>
                        <?php
                        require "../config.php";
                        $adpid = $_SESSION["UserName"];
                        $rowpid = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$adpid'"));
                        if($rowpid['Pid']==1){
                            echo "<li><a href=\"./user.php\">用户管理</a></li><li><a href=\"./shapi.php\">商户信息</a></li>";
                            mysqli_close($mysql_link);
                        }
                        ?>
                        <li class="active"><a href="#">修改密码<span class="sr-only">(current)</span></a></li>
                        <li><a href="./shoplist.php">查看商品</a></li>
                        <li><a href="./showdd.php">订单查看</a></li>
                        <li><a href="ad.php">发布商品</a></li>

                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">管理员：<?php echo $sseion; ?></a></li>
                        <li><a href="./conf/zhuxiaologin.php">注销登录</a></li>

                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">

            <div class="list-group" style="text-align: center">
                <a href="#" class="list-group-item active">
                    修改用户资料
                </a>
                <form action="./conf/rmuser2.php?uid=<?php echo $uid; ?>" method="post" >
                    <ul class="list-group">
                        <li class="list-group-item"><div class="input-group">
                                <span class="input-group-addon" id="sizing-addon2">用户名</span>
                                <input class="form-control" name="adminName"  type="text" value="<?php echo $row['adminName']; ?>" >
                            </div></li>
                        <li class="list-group-item"><div class="input-group">
                                <span class="input-group-addon" id="sizing-addon2">密   码</span>
                                <input type="text" name="adminNpwd" class="form-control" value="<?php echo $row['adminPwd']; ?>" placeholder="新密码" aria-describedby="sizing-addon2">
                            </div></li>
                        <li class="list-group-item"><div class="input-group">
                                <span class="input-group-addon" id="sizing-addon2">Q&nbsp;&nbsp;&nbsp;&nbsp;Q</span>
                                <input type="text" name="adminQq" class="form-control" value="<?php echo $row['adminQq']?>" aria-describedby="sizing-addon2">
                            </div></li>
                        <?php
                        if($row1['Pid']=1){
                            echo "<li class=\"list-group-item\"><div class=\"input-group\">
                            <span class=\"input-group-addon\" id=\"sizing-addon2\">用户组</span>
                            <input type=\"text\" name='adminPid' class=\"form-control\" value=\"{$row['Pid']}\" aria-describedby=\"sizing-addon2\">
                        </div></li>";

                        }
                        ?>
                        <li class="list-group-item"><button type="submit" class="btn btn-info">确认修改</button></li>
                    </ul>
                </form>
            </div>




        </div>
    </div>

</div>

<script src="./jquery-3.2.1/jquery-3.2.1.js"></script>
<script src="./bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>