<div class="container">
    <div class="row">
        <div class="col-md-12">

            <div class="list-group" style="text-align: center">
                <a href="#" class="list-group-item disabled">
                    乘风破浪
                </a>
                <a href="#" class="list-group-item">版本：1.0</a>
                <a href="#" class="list-group-item">如有任何问题，联系技术人员</a>
            </div>
        </div>
    </div>