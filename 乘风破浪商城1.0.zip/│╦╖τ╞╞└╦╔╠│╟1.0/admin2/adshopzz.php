<?php

session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>乘风破浪1.0后台-商品列表</title>
    <link href="./bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="row">
    <div class="col-md-12">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="#">
                                <img alt="Brand" src="./logo.png" width="35px" height="30px">
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li ><a href="index.php">后台首页 </a></li>
                        <?php
                        require "../config.php";
                        $adpid = $_SESSION["UserName"];
                        $rowpid = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$adpid'"));
                        if($rowpid['Pid']==1){
                            echo "<li><a href=\"./user.php\">用户管理</a></li><li><a href=\"./shapi.php\">商户信息</a></li>";
                            mysqli_close($mysql_link);
                        }
                        ?>
                        <li><a href="./rmuser.php">修改密码</a></li>
                        <li><a href="./shoplist.php">查看商品</a></li>
                        <li><a href="./showdd.php">订单查看</a></li>
                        <li class="active"class="active"><a href="./ad.php">发布商品<span class="sr-only">(current)</span></a></li>

                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">管理员：<?php echo $_SESSION["UserName"]; ?></a></li>
                        <li><a href="./conf/zhuxiaologin.php">注销登录</a></li>

                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">

            <div class="list-group" style="text-align: center">
                <a href="#" class="list-group-item active">
                    新增商品
                </a>
                <form action="./conf/shopaddzz.php" method="post" enctype="multipart/form-data" >
                    <ul class="list-group">
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">所属类别</span>
                            <input class="form-control" id="disabledInput" type="text" placeholder="转转手机类" disabled>
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                                <span class="input-group-addon" id="sizing-addon2">商品名称</span>
                                <input type="text" name="s_mz" class="form-control" placeholder="商品名称" aria-describedby="sizing-addon2">
                            </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">商品价格</span>
                            <input type="text" name="s_jg" class="form-control" placeholder="商品价格" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">卖家名称</span>
                            <input type="text" name="s_mjmz" class="form-control" placeholder="卖家名称" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="form-group">

                            <div class="dhna" style="float: left">

                            <select name="s_zt" class="" style="width: 150px;text-align: center" >
                                <option value="#">是否上架</option>
                                <option value="1">上架</option>
                                <option value="2">下架</option>
                            </select>
                                </div>
                            <div class="a4454" style="float: right">

                            <select name="s_pay" class="" style="width: 150px;text-align: center">
                                <option value="#">支付方式</option>
                                <option value="1">微信</option>
                                <option value="2">支付宝</option>
                            </select>
                            </div>
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">点击量</span>
                            <input type="text" name="s_djl" class="form-control" placeholder="点击量" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">商品颜色</span>
                            <input type="text" name="s_ys" class="form-control" placeholder="商品颜色" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">商品内存</span>
                            <input type="text" name="s_nc" class="form-control" placeholder="商品内存" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">购买渠道</span>
                            <input type="text" name="s_qd" class="form-control" placeholder="购买渠道" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">所在地区</span>
                            <input type="text" name="s_dq" class="form-control" placeholder="所在地区" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">商品介绍</span>
                            <textarea class="form-control" name="s_js" rows="3"></textarea>
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">在售宝贝数量</span>
                            <input type="text" name="s_zssl" class="form-control" placeholder="必须填写数字：例如1" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">累计交易数量</span>
                            <input type="text" name="s_jysl" class="form-control" placeholder="必须填写数字，例如1" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2">商品回复率%</span>
                            <input type="text" name="s_hfl" class="form-control" placeholder="必须填数字，90,100此类型" aria-describedby="sizing-addon2">
                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                                <label for="exampleInputFile">商品主图，也是第一张图，必填</label>
                                <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <label for="exampleInputFile">商品第二张图片，可不填</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <label for="exampleInputFile">商品第三张图片，可不填</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <label for="exampleInputFile">商品第四张图片，可不填</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <label for="exampleInputFile">商品第五张图片，可不填</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <label for="exampleInputFile">卖家头像图片，必填</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><div class="input-group">
                            <label for="exampleInputFile">收款码</label>
                            <input type="file" name="myfile[]" id="exampleInputFile">

                        </div></li>
                        <li class="list-group-item"><button type="submit" class="btn btn-info">确认添加</button></li>

                    </ul>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="./jquery-3.2.1/jquery-3.2.1.js"></script>
<script src="./bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>