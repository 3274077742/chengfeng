<?php
session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<?php
    require "../../config.php";
    $suid= $_GET['uid'];
    $s_zt =$_GET['zt'];
    $rowsp = mysqli_query($mysql_link,"UPDATE `shop` SET `s_zt` = '$s_zt' WHERE `shop`.`s_uid` = $suid");
    if($rowsp){
        if($s_zt==1){
        echo "<script language=\"javascript\">
  alert(\"商品上架成功，返回继续浏览\");
  document.location.href=\"../shoplist.php\";
</script>";
        exit;}
        if($s_zt==2){
            echo "<script language=\"javascript\">
  alert(\"商品下架成功，返回继续浏览\");
  document.location.href=\"../shoplist.php\";
</script>";
        }

    }else{
        echo "<script language=\"javascript\">
  alert(\"修改失败\");
  document.location.href=\"../shoplist.php\";
</script>";
        exit;

    }




?>