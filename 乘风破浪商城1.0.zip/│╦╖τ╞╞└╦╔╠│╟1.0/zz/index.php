﻿<?php
    require "../config.php";
    $uid=$_GET['uid'];
    $zt=$_GET['zt'];
    if($uid=='' and $zt==''){
        echo "<script language=\"javascript\">
  alert(\"没有找到商品，返回首页\");
  document.location.href=\"http://zhuanzhuan.58.com/?zzfrom=baidubradingPC1&zhuanzhuanSourceFrom=1223\";
</script>";
        exit;
}

            $cxzt = mysqli_query($mysql_link,"SELECT * FROM shop WHERE `s_uid` = '$uid'");
            $cxzt2 = mysqli_fetch_array($cxzt);
            $cxztid = $cxzt2['s_zt'];
            if($cxztid==2){
                echo "<script language=\"javascript\">
  alert(\"商品已下架，返回首页\");
  document.location.href=\"http://zhuanzhuan.58.com/?zzfrom=baidubradingPC1&zhuanzhuanSourceFrom=1223\";
</script>";
                exit;
            }



    $sqlcx = "SELECT * FROM shop WHERE `s_uid` = $uid";
    $result = mysqli_query($mysql_link,$sqlcx);
    $row = mysqli_fetch_array($result);
mysqli_close($mysql_link);

?>

<html>
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<meta itemprop="name" content=" <?php echo $row['s_mz'].'----'.$row['s_dq']; ?> ">
<meta itemprop="image"   content="tupian/upload/201802041539540973.jpg">
<meta name="description"   itemprop="description" content="<?php echo $row['s_mz']; ?>">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<script src="./js/jqrure.js" ></script>
	    <script src="./js/index.js" ></script>
	    <link type="text/css" rel="styleSheet" href="./js/style.css">
	    <link type="text/css" rel="styleSheet" href="./js/index.css">
        <link rel="Shortcut Icon" href="./imges/favicon.ico" type="image/x-icon"/>
	    <title><?php echo '转转-'.$row['s_mz'].'—'.$row['s_mjmz']; ?></title>
	</head>
	
	<body class="bgColor" style="padding-bottom: 2rem;">
		<div class="whiteBga">
            <?php echo "<h4 class='goodTitle'>".$row['s_mz']."</h4>"; ?>
			<div class="goodPrice clearfix">
				<p class="fl">
					<span>&yen;&nbsp;<em><?php echo $row['s_jg']; ?></em></span>&nbsp;<span>包邮</span>
				</p>
				<span class="skim fr">浏览：<?php echo $row['s_djl']; ?></span>
			</div>
		<div class="location clearfix">
				<span class="fl"><em><?php echo $row['s_dq']; ?></em><img src="./imges/icon25.png"></span>
			</div>
			</div>
			<div class="whiteBgb" >
			<img src="./imges/ing7.jpg" width="100%" />
			</div>
			
		<div class="whiteBg">
			<h4 class="goodTitle">商品详情</h4>
			<ul class="describe clearfix">
				<li><span>机身颜色：</span><span><?php echo $row['s_ys']; ?></span></li>
				<li><span>容量：</span><span><?php echo $row['s_nc']; ?></span></li>
				<li><span>购买渠道：</span><span><?php echo $row['s_qd']; ?></span></li>
			</ul>
			<div class="personIntro">
                <?php echo $row['s_js']; ?>		</div>
			<div class="personIntroAll">
                <?php echo $row['s_js']; ?>				<div>收起</div>
			</div>
			<div class="">
				<div class="picBox">
                    <?php
                        if($row['s_tp1']!=''){
                            echo "<img src=\"../uploads/{$row['s_tp1']}\" />";
                        }
                    if($row['s_tp2']!=''){
                        echo "<img src=\"../uploads/{$row['s_tp2']}\" />";
                    }
                    if($row['s_tp3']!=''){
                        echo "<img src=\"../uploads/{$row['s_tp3']}\" />";
                    }
                    if($row['s_tp4']!=''){
                        echo "<img src=\"../uploads/{$row['s_tp4']}\" />";
                    }
                    if($row['s_tp5']!=''){
                        echo "<img src=\"../uploads/{$row['s_tp5']}\" />";
                    }
                    ?>
                   			</div>
				<ul class="rankImg clearfix">
															</ul>
			</div>
		</div>
		<div class="whiteBg">
			<div class="satisfy clearfix">
				<span class="fl">支持邮寄验机</span>
				<span class="fr">满意度97% <img src="./imges/icon8.png" /></span>
			</div>
			<ul class="promise clearfix">
				<li><span>·</span>专业验机</li><li><span>·</span>30天质保</li><li><span>·</span>顺丰保价包邮</li>
			</ul>
		</div>
		<div class="storeCredit creditBox">
			<div class="shop clearfix">
				<img class="storePic fl" src="../uploads/<?php echo $row['s_mjtx']; ?>" alt="店铺头像" />
				<div class="fl">
					<h4><?php echo $row['s_mjmz']; ?></h4>
					<p class="client"><span>00后</span><span>双鱼座</span><span>男生</span><span>1天前来过</span></p>
				</div>
				<img class="rightIcon fr" src="./imges/icon8.png" />
			</div>
			<ul class="deal clearfix">
				<li><span><?php echo $row['s_zssl']; ?></span><p>在售宝贝</p></li>
				<li><span><?php echo $row['s_jysl']; ?></span><p>累计交易</p></li>
				<li class="replyRate"><span><?php echo $row['s_hfl']; ?><em>%</em></span><p>回复率<img class="question" src="./imges/icon4.png" /></p></li>
				<li class="zhima"><img class="dredge" src="./imges/img2.png" /><p>芝麻信用</p></li>
			</ul>
		</div>
		<div class="interact">
			<div class="wanted clearfix">
				<p class="fl">互动（2）</p>
				<div class="fr">
					<span>2人想要</span>
					<img src="./upload/head.jpeg" />
					<img src="./upload/head1.jpg" />
				</div>
			</div>
			<div class="leaveMsg clearfix">
				<img class="fl" src="./upload/head1.jpg" />
				<div class="msgBox fl">
					<textarea class="msgTxt" placeholder="有想法就说，不吐不快..."></textarea>
					<input class="msgBtn" type="button" value="留言" />
				</div>
			</div>
		</div>
		<div class="fixFooter">
			<div class="clearfix">
				<p class="heart fl">
					<span></span><em>想要</em>
				</p>
                <?php
                echo "<a href=\"./login_1.php?uid=$uid&zt=$zt\" class=\"buy fr\" />马上买</a>";
                ?>

							<a href="javascript:;" class="link fr"><img src="../uploads/<?php echo $row['s_mjtx']; ?>" /><span>联系卖家</span></a>
			</div>
		</div>
		
		<div class="mask levelMask">
			<div class="level">
				<img src="./Public/static/shop/img/img4.png" />
			</div>
		</div>
		
		<div class="mask rate">
			<div class="maskCon ">
				<h3>什么是卖家回复率？</h3>
				<p>卖家回复率：近15天内，在24小时内回复买家咨询的次数/买家咨询的次数。
	    		</p>
	    		<p>·小于50%；回复率较低，一定要先和卖家取得联系后再付款哦。</p>
	    		<p>·大于50%小于80%；回复率正常，通常情况下卖家回复很及时。</p>
	    		<p>·大于80%；回复率很高，卖家近期有问必答。</p>
	    		<p class="cankao">该指标仅作为咨询和交易参考哦。</p>
	    		<input type="button" value="知道了">
			</div>
		</div>
		<script>
			$(function(){
				//回复率
				$(".deal .replyRate").click(function(){
					$(".rate").fadeIn("fast");
				})
				$(".rate .maskCon input").click(function(){
					$(".rate").fadeOut("fast");
				})
				//想要
				$(".heart").click(function(){
					$(this).find("span").toggleClass("active");
				});
				
				//芝麻信用
				$(".zhima").click(function(){
					$(".levelMask").fadeIn("fast");
				})
				$(".levelMask").click(function(){
					$(this).fadeOut("fast");
				});
				
				//展开收起
				$('.personIntro').each(function(){
					var maxwidth=83;
					if($(this).text().length>maxwidth){
						$(this).text($(this).text().substring(0,maxwidth));
						$(this).html($(this).html()+"<span class='spread'>... <em>展开</em></span>");
					}
				});
				$(".spread").click(function(){
					$(".personIntro").hide();
					$(".personIntroAll").show();
				});
				$(".personIntroAll div").click(function(){
					$(".personIntro").show();
					$(".personIntroAll").hide();
				})
				
				//留言
				$(".commentList li").each(function(){
					$(this).find("div .msgName .hui").click(function(){
						if($(this).parent().siblings('.inputTxt').is(':hidden')){
							$(".inputTxt").hide();
							$(".hui").text("回复");
							$(this).parent().siblings('.inputTxt').show();
							$(this).text('提交');
						}else{
							if($(this).parent().siblings('.inputTxt').val()!=''){
								$(this).parent().siblings('.inputTxt').hide();
								$(this).text('回复');
								$(this).parent().siblings('.inputTxt').val('');
							}
						}
					})
				})
			})
		</script>
	</body>
	
</html>