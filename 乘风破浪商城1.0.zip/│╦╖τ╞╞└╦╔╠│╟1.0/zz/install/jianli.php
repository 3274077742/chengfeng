<?php
echo file_put_contents("config2.php","$host = 'localhost'; //数据库地址
\$username = 'root'; //数据库用户名
\$dbpwd = '';  //数据库密码
\$dbname = 'zz';   //数据库名
\$mysqllink = mysqli_connect(\$host,\$username,\$dbpwd,\$dbname);
\$program_char = \"utf8\" ;
mysqli_set_charset( \$mysqllink , \$program_char );",mode,context)
?>