<?php

    $adname=$_POST['adname'];
    $adpwd = $_POST['adpwd'];
    $adqq = $_POST['adqq'];
    $adpid=$_POST['adpid'];
if($adpid !='1' and $adpid!='2'){
    echo "<script language=\"javascript\">
  alert(\"用户组只能为1和2，不能为其他，请重新添加\");
  document.location.href=\"../user.php\";
</script>";
exit;
}
    require "../../config.php";
    $sql = "INSERT INTO `admininfo` (`Uid`, `Pid`, `adminName`, `adminPwd`, `adminQq`) VALUES (NULL, '$adpid', '$adname', '$adpwd','$adqq')";
if(mysqli_query($mysql_link,$sql)){
    echo "<script language=\"javascript\">
  alert(\"新增成功，返回浏览页\");
  document.location.href=\"../user.php\";
</script>";

}else{
    echo "<script language=\"javascript\">
  alert(\"新增失败，用户名不能重复。请重新添加\");
  document.location.href=\"../user.php\";
</script>";
}

mysqli_close($mysql_link);



?>