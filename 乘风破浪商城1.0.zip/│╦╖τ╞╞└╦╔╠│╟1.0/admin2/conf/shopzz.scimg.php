<?php
session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<?php
    require "../../config.php";
    $uid=$_GET['uid'];
    $tihuan =$_GET['i'];
    if($tihuan=="skt"){
        $row = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM shop WHERE s_uid= $uid"));
        if($row['s_pay']=='s_pwx'){
            $tihuan="s_pwx";

        }else{
            $tihuan="s_pzfb";
        }
    }

    $tihuan2 = mysqli_query($mysql_link,"UPDATE `shop` SET `$tihuan` = '' WHERE `shop`.`s_uid` = $uid");{
        if($tihuan2){
            echo "<script language=\"javascript\">
  alert(\"删除成功\");
  document.location.href=\"../shopzz.xiugai.php?uid=$uid\";
</script>";
            exit;
        }else{
            echo 1;
        }
}
?>