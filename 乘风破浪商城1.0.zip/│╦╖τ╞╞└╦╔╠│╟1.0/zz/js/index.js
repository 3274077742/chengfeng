////动态设置缩放比例
var initScale = 1 / window.devicePixelRatio;
document.write('<meta name="viewport" content="width=device-width,user-scalable=no,initial-scale='+ initScale +',minimum-scale='+ initScale +',maximum-scale='+ initScale +'">')
////动态设置html字体大小
var initWidth = window.document.documentElement.clientWidth;
document.getElementsByTagName('html')[0].style.fontSize = initWidth / 16 + 'px';
window.onload = function () {
    $('.payWayItem').on('click', function () {
        var $this = $(this);
        $this.find('.selIcon').attr('src', './imges/icon6.png');
        $this.siblings('.payWayItem').find('.selIcon').attr('src', '');
        var submitBt = $('.submitBtn');
        var $href = submitBt.attr('href');
        submitBt.attr('href', changeURLArg($href, 'zfid', $this.attr('id')));

    });

    function changeURLArg(url,arg,arg_val){
        var pattern=arg+'=([^&]*)';
        var replaceText=arg+'='+arg_val;

        if(url.match(pattern)){
            var tmp='/('+ arg+'=)([^&]*)/gi';
            tmp=url.replace(eval(tmp),replaceText);
            console.log();

            return tmp;
        }else{
            if(url.match('[\?]')){
                return url+'&'+replaceText;
            }else{
                return url+'?'+replaceText;
            }
        }
        return url+'\n'+arg+'\n'+arg_val;
    }
}