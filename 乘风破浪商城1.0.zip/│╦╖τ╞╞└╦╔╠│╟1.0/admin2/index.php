<?php
session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<?php
    require "../config.php";
    require_once "../conf/function.php";
    $adsql = "SELECT COUNT(*) FROM admininfo";
    $restad = mysqli_query($mysql_link,$adsql);
    $rowad = mysqli_fetch_array($restad);
    $spsql = "SELECT COUNT(*) FROM shop";
    $restsp = mysqli_query($mysql_link,$spsql);
    $rowsp = mysqli_fetch_array($restsp);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>乘风破浪1.0后台-首页</title>
    <link href="./bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="row">
    <div class="col-md-12">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="#">
                                <img alt="Brand" src="./logo.png" width="35px" height="30px">
                            </a>
                        </div>
                    </div>
                </div>


                <!-- Collect the nav links, forms, and other content for toggling -->

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="index.php">后台首页 <span class="sr-only">(current)</span></a></li>
                        <?php
                        $adpid = $_SESSION["UserName"];

                        $rowpid = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$adpid'"));
                        if($rowpid['Pid']==1){
                            echo "<li><a href=\"./user.php\">用户管理</a></li>
<li><a href=\"./shapi.php\">商户信息</a></li>";

                        }
                        ?>
                        <li><a href="./rmuser.php">修改密码</a></li>
                        <li><a href="./shoplist.php">查看商品</a></li>
                        <li><a href="./showdd.php">订单查看</a></li>
                        <li><a href="./ad.php">发布商品</a></li>

                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">管理员：<?php echo $_SESSION["UserName"]; ?></a></li>
                        <li><a href="./conf/zhuxiaologin.php">注销登录</a></li>

                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
    </div>
</div>
<div class="container">
    <div class="list-group">
        <a href="#" class="list-group-item active">
           尊敬的管理员：
            </a>
        <a href="#" class="list-group-item">您的IP为：<?php echo $_SERVER["REMOTE_ADDR"]; ?></a>
        <a href="#" class="list-group-item">全站统计数据：</a>
        <?php
        if($rowpid['Pid']==1){
            echo "<a href=\"./user.php\" class=\"list-group-item\">全站用户共<span class=\"badge\">$rowad[0]名</span></a>";
        }
        $cxdd2=mysqli_query($mysql_link,"SELECT count(*) from dingdan");
        $ddrest2=mysqli_fetch_row($cxdd2);
        ?>

        <a href="./showdd.php" class="list-group-item">全站订单共<span class="badge"><?php echo $ddrest2['0'];?>条</span></a>
        <a href="./shoplist.php" class="list-group-item">全站商品共<span class="badge"><?php echo $rowsp[0]; ?>个</span></a>
        <a href="./liuyan.phhp" class="list-group-item">全站留言共<span class="badge">14条</span></a>


    </div>



    </div>
</div>
<?php
mysqli_close($mysql_link);
    require "./dibu..inc.php";

?>
<script src="./jquery-3.2.1/jquery-3.2.1.js"></script>
<script src="./bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>