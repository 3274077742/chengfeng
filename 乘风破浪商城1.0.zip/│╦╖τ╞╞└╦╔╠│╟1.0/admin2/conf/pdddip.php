<?php
require "../../config.php";
$uid= $_GET['uid'];
$ip = $_SERVER["REMOTE_ADDR"];
$cdd =mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `dingdan` WHERE `d_pid` = '$uid' AND `d_ip` = '$ip'"));
//$cdd =mysqli_query($mysql_link,"SELECT * FROM `dingdan` WHERE `d_pid` = '$uid' AND `d_ip` = '$ip'");
    if($cdd!=null){
        echo "<script language=\"javascript\">
  document.location.href=\"../../zz/order2.php?uid=$uid\";
</script>";
    }else{
        echo "<script language=\"javascript\">
  document.location.href=\"../../zz/order.php?uid=$uid\";
</script>";
    }
?>