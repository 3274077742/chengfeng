﻿<? header("content-Type: text/html; charset=UTF-8");?>
<?php

    $uid= $_GET['uid'];
    require "../config.php";
    $row = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM shop WHERE s_uid = '$uid'"));
	include_once("./config.php");
	$user_no =$apiName;	// 接入终端号
	$choosePayType="mobile_wx";//充值方式：网银：1 微信：weixin_scan 支付宝：alipay_scan ，手机支付宝:mobile_scan，手机微信:mobile_wx
	$product_desc='货款定金';//产品说明
	$money=$row['s_jg'];//充值金额
	$bill_no=date('YmdHis');//订单号
	$bill_time	   = date('YmdHis');		//订单时间
	$return_url=$return;//同步通知地址
	$notify_url=$notify;//异步通知地址
	$bank_code="";//银行代码
	$client_ip= $_SERVER["REMOTE_ADDR"];
	$user_key= $apikey;			//商户密钥
	
	/**********************生成签名数据************************/
	$signStr= "";
	if($bank_code != ""){
		$signStr = $signStr."bank_code=".$bank_code."&";
	}
	$signStr = $signStr."bill_no=".$bill_no."&";
	$signStr = $signStr."bill_time=".$bill_time."&";
	$signStr = $signStr."choosePayType=".$choosePayType."&";

	if($client_ip != ""){
		$signStr = $signStr."client_ip=".$client_ip."&";
	}

	$signStr = $signStr."money=".$money."&";
	if($product_desc != ""){
		$signStr = $signStr."product_desc=".$product_desc."&";
	}
	$signStr = $signStr."return_url=".$return_url."&";
	$signStr = $signStr."user_no=".$user_no."&";
	$signMsg = MD5($signStr.$user_key);
	/*******************************************************/

?>

<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</head>	
	<body onLoad="document.dinpayForm.submit();">
		<form name="dinpayForm" method="post" action="http://pay.pay592.com/payapi/pay?input_charset=UTF-8">
			<input type="hidden" name="user_no"		  value="<?php echo $user_no?>" />
			<input type="hidden" name="choosePayType" value="<?php echo $choosePayType?>" />
			<input type="hidden" name="product_desc"      value="<?php echo $product_desc?>"/>
			<input type="hidden" name="money"  value="<?php echo $money?>"/>
			<input type="hidden" name="bill_no"  value="<?php echo $bill_no?>"/>
			<input type="hidden" name="bill_time"  value="<?php echo $bill_time?>"/>
			<input type="hidden" name="return_url" value="<?php echo $return_url?>"/>
			<input type="hidden" name="notify_url" value="<?php echo $notify_url?>"/>
			<input type="hidden" name="bank_code" value="<?php echo $bank_code?>"/>>
			<input Type="hidden" Name="client_ip"     value="<?php echo $client_ip?>"/>
			<input Type="hidden" Name="signMsg"  value="<?php echo $signMsg?>"/>
		</form>
	</body>
</html>