<?php

session_start();
//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>乘风破浪1.0后台-商品列表</title>
    <link href="./bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="row">
    <div class="col-md-12">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <a class="navbar-brand" href="#">
                                <img alt="Brand" src="./logo.png" width="35px" height="30px">
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">后台首页</a></li>
                        <?php
                        require "../config.php";
                        $adpid = $_SESSION["UserName"];
                        $rowpid = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE `adminName` = '$adpid'"));
                        if($rowpid['Pid']==1){
                            echo "<li><a href=\"./user.php\">用户管理</a></li><li><a href=\"./shapi.php\">商户信息</a></li>";
                            mysqli_close($mysql_link);
                        }
                        ?>
                        <li><a href="./rmuser.php">修改密码</a></li>
                        <li><a href="./shoplist.php">查看商品</a></li>
                        <li><a href="./showdd.php">订单查看</a></li>
                        <li class="active"><a href="#">发布商品<span class="sr-only">(current)</span></a></li>

                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">管理员：<?php echo $_SESSION["UserName"]; ?></a></li>
                        <li><a href="./conf/zhuxiaologin.php">注销登录</a></li>


                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">

            <div class="list-group" >
                <div class="mnih" style="text-align: center">
                    <a href="#" class="list-group-item active">
                        新增商品
                    </a>
                </div>
                <a href="./adshopzz.php" class="list-group-item"><span class="badge">14</span>转转商品</a>
                <a href="#" class="list-group-item"><span class="badge">14</span>闲鱼商品</a>
                <a href="#" class="list-group-item"><span class="badge">14</span>猎趣商品</a>
                <a href="#" class="list-group-item"><span class="badge">14</span>游戏商品</a>
            </div>




        </div>
    </div>

</div>
<?php
require "./dibu..inc.php";
?>
<script src="./jquery-3.2.1/jquery-3.2.1.js"></script>
<script src="./bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
</body>
</html>