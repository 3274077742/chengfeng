<?php
session_start();

//  防止绕过登陆直接进入主界面
if(empty($_SESSION["UserName"]))
{
    echo "<script language=\"javascript\">
  alert(\"没有权限，请勿非法登录\");
  document.location.href=\"./login.php\";
</script>";
    exit;

}
?>
<?php

    require "../../config.php";
    $adminName=$_SESSION["UserName"];
    $adminQq = $_POST['adminQq'];
    $adminPwd =$_POST['adminPwd'];
    $adminNpwd = $_POST['adminNpwd'];
    if($adminPwd=='' and $adminNpwd==''){
        echo "<script language=\"javascript\">
  alert(\"密码不能为空\");
  document.location.href=\"../rmuser.php\";
</script>";
        exit;
    }
    $row1 = mysqli_fetch_array(mysqli_query($mysql_link,"SELECT * FROM `admininfo` WHERE adminName = '$adminName'"));

    if($row1['adminPwd']!=$adminPwd){
        echo "<script language=\"javascript\">
  alert(\"原密码不正确，请重新输入\")
  document.location.href=\"../rmuser.php\";
</script>";
        mysqli_close($mysql_link);
    }else{
        if(mysqli_query($mysql_link,"UPDATE `admininfo` SET `adminPwd` = '$adminNpwd', `adminQq` = '$adminQq' WHERE `admininfo`.`adminName` = '$adminName'"))
        {
            echo "<script language=\"javascript\">
  alert(\"修改成功，返回首页！\");
  document.location.href=\"../index.php\"; 
</script>";
            mysqli_close($mysql_link);
            exit;
        }else{
            echo "<script language=\"javascript\">
  alert(\"修改失败，返回首页！\");
  document.location.href=\"../rmuser.php\"; 
</script>";
            mysqli_close($mysql_link);
            exit;
        }
    }

?>