<?php
session_start();
unset($_SESSION["UserName"]);
echo "<script language=\"javascript\">
  alert(\"注销成功，返回登录页\");
  document.location.href=\"../login.php\";
</script>";
exit;
?>